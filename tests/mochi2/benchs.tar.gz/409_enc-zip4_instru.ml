open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec zip x y =
  let r = if x = 0
          then (if y = 0 then 0 else assert false)
          else
            if y = 0
            then assert false
            else
              (let __atmp5 = 1 in
               let __atmp7 = x - 1 in
               let __atmp9 = y - 1 in
               let __atmp6 = 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_11_26" in 
                 let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                 let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 zip __atmp7 __atmp9 in
               __atmp5 + __atmp6)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "zip" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp13 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_10_17" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in zip n n in
          let m = __atmp13 in
          let __atmp15 = m >= n in
          let __atmp16 = m <= n in assert (__atmp15 && __atmp16)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 