open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopc i j k n m =
  let r = let __atmp2 = n + m in
          if k < __atmp2
          then
            ((let __atmp6 = i + j in
              let __atmp8 = n + k in
              let __atmp7 = __atmp8 + m in assert (__atmp6 <= __atmp7));
             (let __atmp3 = k + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_2_21" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopc i j
                                                                    __atmp3 n
                                                                    m))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopc" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopb i j (n : int) (m : int) =
  let r = if j < n
          then
            (
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_3_18" in 
             let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
             let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopc i j j
                                                                   n m;
             (let __atmp10 = j + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_2_19" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopb i
                                                                    __atmp10
                                                                    n m))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopb" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopa i (n : int) (m : int) =
  let r = if i < n
          then
            ((let __atmp15 = 0 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_3_16" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopb i
                                                                    __atmp15
                                                                    n m);
             (let __atmp13 = i + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_2_17" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp13
                                                                    n m))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n m =
  let r = if n <= m
          then
            let __atmp17 = 0 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_2_13" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp17
                                                                    n m
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp18 = 2 in
  let __atmp19 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "26_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp18
                                                          __atmp19
let _ =
  let __atmp20 = 2 in
  let __atmp21 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "27_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp20
                                                          __atmp21
let _ =
  let __atmp22 = 3 in
  let __atmp23 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "28_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp22
                                                          __atmp23
let _ =
  let __atmp24 = 1 in
  let __atmp25 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "29_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") ((__atmp24)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp24
                                                          __atmp25
let _ =
  let __atmp26 = 1 in
  let __atmp27 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "30_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp26
                                                          __atmp27
let _ =
  let __atmp28 = 0 in
  let __atmp29 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "31_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp28
                                                          __atmp29
let _ =
  let __atmp30 = 0 in
  let __atmp31 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "32_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") ((__atmp30)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp31:%d\t") ((__atmp31)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp30
                                                          __atmp31
let _ =
  let __atmp32 = 2 in
  let __atmp33 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "33_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp32:%d\t") ((__atmp32)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp33:%d\t") ((__atmp33)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp32
                                                          __atmp33
let _ =
  let __atmp34 = (-2) in
  let __atmp35 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "34_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp34:%d\t") ((__atmp34)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp35:%d\t") ((__atmp35)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp34
                                                          __atmp35
let _ = close_out outch 