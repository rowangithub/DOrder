open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let g (x : int) = let r = let __atmp1 = 2 in 2 * x 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "g" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let twice (x : int) f =
  let r = let __atmp2 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_1_6" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f x in
           let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_1_10" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f __atmp2
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "twice" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("f:"); (try fprintf outch ("f_0#%d,") (((f x))) with _->()); 
  (try fprintf outch ("f_r#%d\t") ((f (f x))) with _->(fprintf outch ("	"))); 
  (callflag := true))  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("f:"); fprintf outch ("f_0#%d,") ((x)); 
  (try fprintf outch ("f_r#%d\t") ((f x)) with _->(fprintf outch ("	"))); 
  (callflag := true)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let neg x = let r = let __atmp3 = 0 in __atmp3 - x 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "neg" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp5 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_15_20" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in g n in
          let __atmp4 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_9_24" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in twice __atmp5
                                                                  neg in
          let z = __atmp4 in
          if n > 0 then assert (z >= 0) else assert (z <= 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp12 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp12
let _ =
  let __atmp13 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp13
let _ = close_out outch 