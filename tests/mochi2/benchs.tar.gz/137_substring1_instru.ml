open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop (k : int) i j =
  let r = if i < k
          then
            let __atmp4 = i + 1 in
            let __atmp6 = j + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_2_20" in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop k
                                                                    __atmp4
                                                                    __atmp6
          else assert (j < 101)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main k from =
  let r = let __atmp9 = k >= 0 in
          let __atmp12 = k <= 100 in
          let __atmp15 = from >= 0 in
          let __atmp17 = from <= k in
          let __atmp14 = __atmp15 && __atmp17 in
          let __atmp11 = __atmp12 && __atmp14 in
          if __atmp9 && __atmp11
          then
            let i = from in
            let __atmp18 = 0 in
            let j = __atmp18 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_2_12" in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("from:%d\t") ((from)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") (if (__atmp9) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") (if (__atmp12) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") (if (__atmp15) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") (if (__atmp17) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") (if (__atmp14) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") (if (__atmp11) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop k i j
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("from:%d\t") ((from)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp19 = 20 in
  let __atmp20 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp19
                                                          __atmp20
let _ =
  let __atmp21 = 9 in
  let __atmp22 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp21
                                                          __atmp22
let _ =
  let __atmp23 = 0 in
  let __atmp24 = 9 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") ((__atmp24)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp23
                                                          __atmp24
let _ =
  let __atmp25 = 5 in
  let __atmp26 = 20 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp25
                                                          __atmp26
let _ =
  let __atmp27 = 200 in
  let __atmp28 = 200 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_8_20" in 
    let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp27
                                                          __atmp28
let _ =
  let __atmp29 = (-1) in
  let __atmp30 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") ((__atmp30)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp29
                                                          __atmp30
let _ = close_out outch 