open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let f (g : int -> int -> int) x y =
  let r = let __atmp1 = x + 1 in
          let __atmp3 = y + 1 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_30_47" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp1:%d\t") ((__atmp1)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in g __atmp1
                                                                  __atmp3
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = for v0 = min([-1]) to max([1]) do for v1 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("g:"); 
     fprintf outch ("g_0#%d,") ((v0)); fprintf outch ("g_1#%d,") ((v1));  
     (try fprintf outch ("g_r#%d\t") ((g v0 v1)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done done 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec unzip x (k : int -> int -> int) =
  let r = if x = 0
          then
            let __atmp10 = 0 in
            let __atmp11 = 0 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_4_9" in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in k __atmp10
                                                                    __atmp11
          else
            (let __atmp7 = x - 1 in
             let __atmp9 = f k in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_4_23" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in unzip
                                                                    __atmp7
                                                                    __atmp9)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "unzip" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = for v0 = min([x-1]) to max([x+1]) do for v1 = min([x-1]) to max([x+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("k:"); 
     fprintf outch ("k_0#%d,") ((v0)); fprintf outch ("k_1#%d,") ((v1));  
     (try fprintf outch ("k_r#%d\t") ((k v0 v1)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done done 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec zip x y =
  let r = if x = 0
          then (assert (y = 0); 0)
          else
            (assert (y <> 0);
             (let __atmp14 = 1 in
              let __atmp16 = x - 1 in
              let __atmp18 = y - 1 in
              let __atmp15 = 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_29_48" in 
                let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in zip
                                                                    __atmp16
                                                                    __atmp18 in
              __atmp14 + __atmp15))
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "zip" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_13_24" in 
    let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in unzip n zip 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp24 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") ((__atmp24)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp24
let _ = close_out outch 