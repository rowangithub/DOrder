open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let lock st = let r = assert (st = 0); 10 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "lock" 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let unlock st = let r = assert (st = 10); 0 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "unlock" 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let f n st =
  let r = (if n > 0
           then 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_32_41" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in lock st
           else st : int )
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let g n st =
  let r = (if n > 0
           then 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_33_44" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in unlock st
           else st : int )
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "g" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp7 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_26_33" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f n 0 in
          let __atmp6 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_21_34" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in g n __atmp7 in
          assert (__atmp6 = 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp10 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp10
let _ =
  let __atmp11 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp11
let _ =
  let __atmp12 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp12
let _ =
  let __atmp13 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp13
let _ =
  let __atmp14 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp14
let _ =
  let __atmp15 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp15
let _ =
  let __atmp16 = (-3) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp16
let _ = close_out outch 