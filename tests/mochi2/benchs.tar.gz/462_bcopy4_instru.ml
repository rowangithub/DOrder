open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let array1 i = let r = 0 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "array1" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let array2 i = let r = 0 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "array2" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let update a i x j =
  let r = if j = i
          then x
          else 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_40_43" in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in a j
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "update" 
  in let _ = for v0 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("a:"); 
     fprintf outch ("a_0#%d,") ((v0));  
     (try fprintf outch ("a_r#%d\t") ((a v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec bcopy_aux m src des i =
  let r = if i >= m
          then ()
          else
            ((let __atmp8 = 0 <= i in
              let __atmp10 = i <= m in assert (__atmp8 && __atmp10));
             (let __atmp4 = 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_29_36" in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in src i in
              let __atmp3 = update des i __atmp4 in
              let des = __atmp3 in
              let __atmp5 = i + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_8_33" in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in bcopy_aux
                                                                    m src des
                                                                    __atmp5))
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "bcopy_aux" 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = for v0 = min([m-1]) to max([m+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("src:"); 
     fprintf outch ("src_0#%d,") ((v0));  
     (try fprintf outch ("src_r#%d\t") ((src v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = for v0 = min([m-1]) to max([m+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("des:"); 
     fprintf outch ("des_0#%d,") ((v0));  
     (try fprintf outch ("des_r#%d\t") ((des v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp12 src des =
            let r = let __atmp11 = 0 in 
                      let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_22_43" in 
                      let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                      let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
                      let _ = if (!callflag) then fprintf outch ("\n") in 
                      bcopy_aux n src des __atmp11
               in let _ = if (!callflag) then fprintf outch ("name:%s\t") "__atmp12" 
            in let _ = for v0 = min([n-1]) to max([n+1]) do  
            if (!callflag) then ( (callflag := false); 
               fprintf outch ("src:");  fprintf outch ("src_0#%d,") ((v0));  
               (try fprintf outch ("src_r#%d\t") ((src v0); 0) with _->(fprintf outch ("	"))); 
               (callflag := true);) done 
            in let _ = for v0 = min([n-1]) to max([n+1]) do  
            if (!callflag) then ( (callflag := false); 
               fprintf outch ("des:");  fprintf outch ("des_0#%d,") ((v0));  
               (try fprintf outch ("des_r#%d\t") ((des v0); 0) with _->(fprintf outch ("	"))); 
               (callflag := true);) done 
            in let _ = if (!callflag) then fprintf outch ("\n") in r in
          let bcopy = __atmp12 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_2_21" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in bcopy array1
                                                                  array2
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 