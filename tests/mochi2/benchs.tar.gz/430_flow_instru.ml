open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let lamp x = let r = x 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "lamp" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let f =
  let __atmp1 x = let r = x 
    in let _ = if (!callflag) then fprintf outch ("name:%s\t") "__atmp1" 
    in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
    in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
    in let _ = if (!callflag) then fprintf outch ("\n") in r in
  let id = __atmp1 in
  let __atmp3 _ = let r = assert false 
    in let _ = if (!callflag) then fprintf outch ("name:%s\t") "__atmp3" 
    in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
    in let _ = if (!callflag) then fprintf outch ("\n") in r in
  let __atmp2 = id __atmp3 in let unused = __atmp2 in lamp
let main i =
  let r = let __atmp4 = () in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_13_17" in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f __atmp4
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 