open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec rev n m =
  let r = if n = 0
          then m
          else
            (let __atmp3 = n - 1 in
             let __atmp5 = m + 1 in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_7_26" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in rev
                                                                    __atmp3
                                                                    __atmp5)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "rev" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp8 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_10_17" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in rev n 0 in
          assert (__atmp8 >= n)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 