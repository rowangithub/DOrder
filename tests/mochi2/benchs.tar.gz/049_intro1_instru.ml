open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let f x g =
  let r = (
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_19_25" in 
    let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in g (x + 1) : unit ) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = for v0 = min([x-1]) to max([x+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("g:"); 
     fprintf outch ("g_0#%d,") ((v0));  
     (try fprintf outch ("g_r#%d\t") ((g v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let h y = let r = assert (y > 0) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "h" 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = if n > 0
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_25_30" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f n h
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp5 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp5
let _ = close_out outch 