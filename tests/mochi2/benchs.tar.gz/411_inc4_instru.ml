open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let make_array n i =
  let r = (let __atmp2 = 0 <= i in
           let __atmp4 = i < n in assert (__atmp2 && __atmp4));
          0
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "make_array" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let update i n des x =
  let r = 
          let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_23_28" in 
          let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
          let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
          let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
          let _ = if (!callflag) then fprintf outch ("\n") in des i;
          (let __atmp6 j =
             let r = if i = j
                     then x
                     else 
                       let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_59_64" in 
                       let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                       let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                       let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                       let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                       let _ = if (!callflag) then fprintf outch ("\n") in 
                       des i
                in let _ = if (!callflag) then fprintf outch ("name:%s\t") "__atmp6" 
             in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
             in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
             in let _ = if (!callflag) then fprintf outch ("\n") in r in
           let a = __atmp6 in a)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "update" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = for v0 = min([i-1;  n-1]) to max([i+1;  n+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("des:"); 
     fprintf outch ("des_0#%d,") ((v0));  
     (try fprintf outch ("des_r#%d\t") ((des v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec inc3 m a i =
  let r = if i >= m
          then ()
          else
            (let __atmp10 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_25_30" in 
               let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in a i in
             let __atmp9 = __atmp10 + 1 in
             let __atmp8 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_11_33" in 
               let _ = if (!callflag) then fprintf outch ("\n") in update i m
                                                                    a __atmp9 in
             let a = __atmp8 in
             let __atmp12 = i + 1 in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_5_19" in 
               let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in inc3 m a
                                                                    __atmp12)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "inc3" 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = for v0 = min([m-1]) to max([m+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("a:"); 
     fprintf outch ("a_0#%d,") ((v0));  
     (try fprintf outch ("a_r#%d\t") ((a v0)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n i =
  let r = let __atmp15 = i = 0 in
          let __atmp17 = n > 0 in
          if __atmp15 && __atmp17
          then
            let __atmp19 = make_array n in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_21_44" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") (if (__atmp15) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") (if (__atmp17) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("\n") in inc3 n
                                                                    __atmp19
                                                                    i
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 