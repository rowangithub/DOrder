open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let app (a : int) (f : int -> (int -> unit) -> unit) (a : int)
  (g : int -> unit) =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_67_72" in 
    let _ = if (!callflag) then fprintf outch ("a:%d\t") ((a)) in 
    let _ = if (!callflag) then fprintf outch ("a:%d\t") ((a)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in f a g 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "app" 
  in let _ = if (!callflag) then fprintf outch ("a:%d\t") ((a)) 
  in let _ = for v0 = min([a-1]) to max([a+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("f:"); 
     fprintf outch ("f_0#%d,") ((v0));  
     (try fprintf outch ("f_r#%d\t") ((f v0 g); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("a:%d\t") ((a)) 
  in let _ = for v0 = min([a-1;  a-1]) to max([a+1;  a+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("g:"); 
     fprintf outch ("g_0#%d,") ((v0));  
     (try fprintf outch ("g_r#%d\t") ((g v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let f x (a : int) (k : int -> unit) =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_32_35" in 
    let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
    let _ = if (!callflag) then fprintf outch ("a:%d\t") ((a)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in k x 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("a:%d\t") ((a)) 
  in let _ = for v0 = min([x-1;  a-1]) to max([x+1;  a+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("k:"); 
     fprintf outch ("k_0#%d,") ((v0));  
     (try fprintf outch ("k_r#%d\t") ((k v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let check (x : int) (y : int) = let r = assert (x = y) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "check" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main a b =
  let r = let __atmp3 = 4 * a in
          let __atmp5 = 2 * b in
          let __atmp2 = __atmp3 + __atmp5 in
          let __atmp9 = 4 * a in
          let __atmp11 = 2 * b in
          let __atmp8 = __atmp9 + __atmp11 in
          let __atmp7 = f __atmp8 in
          let __atmp14 = 4 * a in
          let __atmp16 = 2 * b in
          let __atmp13 = __atmp14 + __atmp16 in
          let __atmp20 = 4 * a in
          let __atmp22 = 2 * b in
          let __atmp19 = __atmp20 + __atmp22 in
          let __atmp18 = check __atmp19 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_15_94" in 
            let _ = if (!callflag) then fprintf outch ("a:%d\t") ((a)) in 
            let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in app __atmp2
                                                                  __atmp7
                                                                  __atmp13
                                                                  __atmp18
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("a:%d\t") ((a)) 
  in let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp24 = 1 in
  let __atmp25 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") ((__atmp24)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp24
                                                          __atmp25
let _ = close_out outch 