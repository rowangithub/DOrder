open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec ar i = let r = 0 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "ar" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let update a i x j =
  let r = if j = i
          then x
          else 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_40_43" in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in a j
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "update" 
  in let _ = for v0 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("a:"); 
     fprintf outch ("a_0#%d,") ((v0));  
     (try fprintf outch ("a_r#%d\t") ((a v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec g e a j =
  let r = if j < e
          then
            ((let __atmp10 = 0 <= j in
              let __atmp12 = j < e in assert (__atmp10 && __atmp12));
             (let __atmp5 = 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_21_25" in 
                let _ = if (!callflag) then fprintf outch ("e:%d\t") ((e)) in 
                let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in a j in
              let __atmp4 = __atmp5 + 1 in
              let __atmp3 = update a j __atmp4 in
              let __atmp7 = j + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_4_35" in 
                let _ = if (!callflag) then fprintf outch ("e:%d\t") ((e)) in 
                let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in g e
                                                                    __atmp3
                                                                    __atmp7))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "g" 
  in let _ = if (!callflag) then fprintf outch ("e:%d\t") ((e)) 
  in let _ = for v0 = min([e-1]) to max([e+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("a:"); 
     fprintf outch ("a_0#%d,") ((v0));  
     (try fprintf outch ("a_r#%d\t") ((a v0)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp13 = 0 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_1_9" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in g n ar
                                                                  __atmp13
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 