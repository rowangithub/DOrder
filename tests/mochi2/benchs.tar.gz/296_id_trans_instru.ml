open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop j idBitLength material_length nelen =
  let r = let __atmp3 = 8 * j in
          let __atmp2 = __atmp3 < idBitLength in
          let __atmp5 = j < material_length in
          if __atmp2 && __atmp5
          then
            let __atmp8 = assert (0 <= j) in
            let _ = __atmp8 in
            let __atmp10 = assert (j < material_length) in
            let _ = __atmp10 in
            let __atmp15 = let __atmp13 = j / 4 in assert (0 <= __atmp13) in
            let _ = __atmp15 in
            let __atmp19 = let __atmp17 = 4 * nelen in assert (j < __atmp17) in
            let _ = __atmp19 in
            let __atmp20 = j + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_2_46" in 
              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
              let _ = if (!callflag) then fprintf outch ("idBitLength:%d\t") ((idBitLength)) in 
              let _ = if (!callflag) then fprintf outch ("material_length:%d\t") ((material_length)) in 
              let _ = if (!callflag) then fprintf outch ("nelen:%d\t") ((nelen)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") (if (__atmp2) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") (if (__atmp5) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp20
                                                                    idBitLength
                                                                    material_length
                                                                    nelen
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("idBitLength:%d\t") ((idBitLength)) 
  in let _ = if (!callflag) then fprintf outch ("material_length:%d\t") ((material_length)) 
  in let _ = if (!callflag) then fprintf outch ("nelen:%d\t") ((nelen)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main idBitLength material_length nelen =
  let r = let __atmp23 = 32 * nelen in
          if __atmp23 >= idBitLength
          then
            let __atmp25 = 0 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_2_42" in 
              let _ = if (!callflag) then fprintf outch ("idBitLength:%d\t") ((idBitLength)) in 
              let _ = if (!callflag) then fprintf outch ("material_length:%d\t") ((material_length)) in 
              let _ = if (!callflag) then fprintf outch ("nelen:%d\t") ((nelen)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp25
                                                                    idBitLength
                                                                    material_length
                                                                    nelen
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("idBitLength:%d\t") ((idBitLength)) 
  in let _ = if (!callflag) then fprintf outch ("material_length:%d\t") ((material_length)) 
  in let _ = if (!callflag) then fprintf outch ("nelen:%d\t") ((nelen)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp26 = (-2) in
  let __atmp27 = (-2) in
  let __atmp28 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "23_8_27" in 
    let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp26
                                                          __atmp27 __atmp28

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)  (12)  (15)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)  (17)  (17)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (17)  (10)  (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)  (-9)  (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)  (4)  (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)  (-9)  (-6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)  (-2)  (0)
let _ = close_out outch