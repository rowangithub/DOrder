open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x =
  let r = (
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_24_31" in 
    let _ = if (!callflag) then fprintf outch ("\n") in loop () : unit ) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let init = 0
let opened = 1
let closed = 2
let ignore = 3
let readit st =
  let r = if st = opened
          then opened
          else if st = ignore then st else assert false
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "readit" 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let read_ x st =
  let r = if x
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_12_21" in 
            let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
            let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
            let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
            let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) in 
            let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in readit st
          else st
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "read_" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let closeit st =
  let r = if st = opened
          then closed
          else
            if st = ignore
            then st
            else
              ((let __atmp5 = () in 
                  let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_64_71" in 
                  let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
                  let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
                  let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
                  let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
                  let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
                  let _ = if (!callflag) then fprintf outch ("\n") in 
                  loop __atmp5);
               0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "closeit" 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let close_ x st =
  let r = if x
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_12_22" in 
            let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
            let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
            let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
            let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) in 
            let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in closeit st
          else st
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "close_" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec f x y st =
  let r = (
           let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_2_24" in 
           let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
           let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
           let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
           let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
           let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) in 
           let _ = if (!callflag) then fprintf outch ("y:%d\t") (if (y) then 1 else 0) in 
           let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
           let _ = if (!callflag) then fprintf outch ("\n") in close_ y (
                                                                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_11_24" in 
                                                                 let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
                                                                 let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
                                                                 let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
                                                                 let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
                                                                 let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) in 
                                                                 let _ = if (!callflag) then fprintf outch ("y:%d\t") (if (y) then 1 else 0) in 
                                                                 let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
                                                                 let _ = if (!callflag) then fprintf outch ("\n") in 
                                                                 close_ x st);
           
           let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_26_54" in 
           let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
           let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
           let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
           let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
           let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) in 
           let _ = if (!callflag) then fprintf outch ("y:%d\t") (if (y) then 1 else 0) in 
           let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
           let _ = if (!callflag) then fprintf outch ("\n") in f x y (
                                                                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_32_54" in 
                                                                 let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
                                                                 let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
                                                                 let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
                                                                 let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
                                                                 let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) in 
                                                                 let _ = if (!callflag) then fprintf outch ("y:%d\t") (if (y) then 1 else 0) in 
                                                                 let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
                                                                 let _ = if (!callflag) then fprintf outch ("\n") in 
                                                                 read_ y (
                                                                   let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_41_53" in 
                                                                   let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
                                                                   let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
                                                                   let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
                                                                   let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
                                                                   let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) in 
                                                                   let _ = if (!callflag) then fprintf outch ("y:%d\t") (if (y) then 1 else 0) in 
                                                                   let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
                                                                   let _ = if (!callflag) then fprintf outch ("\n") in 
                                                                   read_ x st)) : 
    unit ) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") (if (y) then 1 else 0) 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let next st = let r = if st = init then opened else ignore 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "next" 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let g b3 x st =
  let r = if b3 > 0
          then
            let __atmp10 = true in
            let __atmp11 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "23_40_49" in 
              let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
              let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
              let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
              let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
              let _ = if (!callflag) then fprintf outch ("b3:%d\t") ((b3)) in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") (if (__atmp10) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("\n") in next st in
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "23_31_49" in 
              let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
              let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
              let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
              let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
              let _ = if (!callflag) then fprintf outch ("b3:%d\t") ((b3)) in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") (if (__atmp10) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in f x
                                                                    __atmp10
                                                                    __atmp11
          else
            (let __atmp9 = false in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "23_55_67" in 
               let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
               let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
               let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
               let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
               let _ = if (!callflag) then fprintf outch ("b3:%d\t") ((b3)) in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) in 
               let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") (if (__atmp9) then 1 else 0) in 
               let _ = if (!callflag) then fprintf outch ("\n") in f x
                                                                    __atmp9
                                                                    st)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "g" 
  in let _ = if (!callflag) then fprintf outch ("b3:%d\t") ((b3)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") (if (x) then 1 else 0) 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main b2 b3 =
  let r = if b2 > 0
          then
            (let __atmp15 = true in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_33_49" in 
               let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
               let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
               let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
               let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
               let _ = if (!callflag) then fprintf outch ("b2:%d\t") ((b2)) in 
               let _ = if (!callflag) then fprintf outch ("b3:%d\t") ((b3)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") (if (__atmp15) then 1 else 0) in 
               let _ = if (!callflag) then fprintf outch ("\n") in g b3
                                                                    __atmp15
                                                                    opened)
          else
            (let __atmp14 = false in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_55_70" in 
               let _ = if (!callflag) then fprintf outch ("init:%d\t") ((init)) in 
               let _ = if (!callflag) then fprintf outch ("opened:%d\t") ((opened)) in 
               let _ = if (!callflag) then fprintf outch ("closed:%d\t") ((closed)) in 
               let _ = if (!callflag) then fprintf outch ("ignore:%d\t") ((ignore)) in 
               let _ = if (!callflag) then fprintf outch ("b2:%d\t") ((b2)) in 
               let _ = if (!callflag) then fprintf outch ("b3:%d\t") ((b3)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") (if (__atmp14) then 1 else 0) in 
               let _ = if (!callflag) then fprintf outch ("\n") in g b3
                                                                    __atmp14
                                                                    init);
          ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("b2:%d\t") ((b2)) 
  in let _ = if (!callflag) then fprintf outch ("b3:%d\t") ((b3)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 