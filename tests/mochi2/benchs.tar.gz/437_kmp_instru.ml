open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let make_array n s i =
  let r = (let __atmp2 = 0 <= i in
           let __atmp4 = i < n in assert (__atmp2 && __atmp4));
          s
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "make_array" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("s:%d\t") ((s)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let update i n a x =
  let r = 
          let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_21_24" in 
          let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
          let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
          let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
          let _ = if (!callflag) then fprintf outch ("\n") in a i;
          (let __atmp6 j =
             let r = if i = j
                     then x
                     else 
                       let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_55_58" in 
                       let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                       let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                       let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                       let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                       let _ = if (!callflag) then fprintf outch ("\n") in 
                       a j
                in let _ = if (!callflag) then fprintf outch ("name:%s\t") "__atmp6" 
             in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
             in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
             in let _ = if (!callflag) then fprintf outch ("\n") in r in
           let a = __atmp6 in a)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "update" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("a:"); fprintf outch ("a_0#%d,") ((i)); 
  (try fprintf outch ("a_r#%d\t") ((a i)) with _->(fprintf outch ("	"))); 
  (callflag := true)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let kmpMatch slen str plen pat =
  let r = let __atmp7 = make_array plen (-1) in
          let shiftArray0 = __atmp7 in
          let rec loopShift i j shiftArray1 =
            let r = if j = plen
                    then shiftArray1
                    else
                      (let __atmp12 = 
                         let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_14_19" in 
                         let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                         let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                         let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                         let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                         let _ = if (!callflag) then fprintf outch ("\n") in 
                         pat j in
                       let __atmp14 = i + 1 in
                       let __atmp13 = 
                         let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_22_31" in 
                         let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                         let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                         let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                         let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                         let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                         let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
                         let _ = if (!callflag) then fprintf outch ("\n") in 
                         pat __atmp14 in
                       let __atmp11 = __atmp12 = __atmp13 in
                       if not __atmp11
                       then
                         (if i >= 0
                          then
                            let __atmp30 = 
                              let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_20_35" in 
                              let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                              let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") (if (__atmp11) then 1 else 0) in 
                              let _ = if (!callflag) then fprintf outch ("\n") in 
                              shiftArray1 i in
                             let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_10_49" in 
                              let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                              let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") (if (__atmp11) then 1 else 0) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") ((__atmp30)) in 
                              let _ = if (!callflag) then fprintf outch ("\n") in 
                              loopShift __atmp30 j shiftArray1
                          else
                            (let __atmp27 = (-1) in
                             let __atmp28 = j + 1 in 
                               let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_13_45" in 
                               let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                               let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                               let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                               let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                               let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
                               let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
                               let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") (if (__atmp11) then 1 else 0) in 
                               let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
                               let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
                               let _ = if (!callflag) then fprintf outch ("\n") in 
                               loopShift __atmp27 __atmp28 shiftArray1))
                       else
                         (let __atmp17 = i + 1 in
                          let __atmp21 =
                            if __atmp17 < j
                            then
                              let __atmp19 = i + 1 in 
                                let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_42_73" in 
                                let _ = if (!callflag) then fprintf outch ("\n") in 
                                update j plen shiftArray1 __atmp19
                            else shiftArray1 in
                          let shiftArray2 = __atmp21 in
                          let __atmp22 = 
                            let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_20_35" in 
                            let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                            let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                            let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                            let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                            let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
                            let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
                            let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") (if (__atmp11) then 1 else 0) in 
                            let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
                            let _ = if (!callflag) then fprintf outch ("\n") in 
                            shiftArray1 j in
                          let __atmp23 = j + 1 in 
                            let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_10_53" in 
                            let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                            let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                            let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                            let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                            let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
                            let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
                            let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") (if (__atmp11) then 1 else 0) in 
                            let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
                            let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
                            let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
                            let _ = if (!callflag) then fprintf outch ("\n") in 
                            loopShift __atmp22 __atmp23 shiftArray2))
               in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopShift" 
            in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
            in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
            in let _ = if (!callflag) then ((callflag := false); 
            fprintf outch ("shiftArray1:"); fprintf outch ("shiftArray1_0#%d,") ((
                                            (0 - 1))); 
            (try fprintf outch ("shiftArray1_r#%d\t") ((shiftArray1 (0 - 1))) with _->(fprintf outch ("	"))); 
            (callflag := true)) 
            in let _ = if (!callflag) then ((callflag := false); 
            fprintf outch ("shiftArray1:"); fprintf outch ("shiftArray1_0#%d,") ((i)); 
            (try fprintf outch ("shiftArray1_r#%d\t") ((shiftArray1 i)) with _->(fprintf outch ("	"))); 
            (callflag := true)) 
            in let _ = if (!callflag) then ((callflag := false); 
            fprintf outch ("shiftArray1:"); fprintf outch ("shiftArray1_0#%d,") ((j)); 
            (try fprintf outch ("shiftArray1_r#%d\t") ((shiftArray1 j)) with _->(fprintf outch ("	"))); 
            (callflag := true)) 
            in let _ = if (!callflag) then ((callflag := false); 
            fprintf outch ("r:"); fprintf outch ("r_0#%d,") (((0 - 1))); 
            (try fprintf outch ("r_r#%d\t") ((r (0 - 1))) with _->(fprintf outch ("	"))); 
            (callflag := true)) 
            in let _ = if (!callflag) then fprintf outch ("\n") in r in
          let __atmp31 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_20_48" in 
            let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
            let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopShift
                                                                  (-1) 1
                                                                  shiftArray0 in
          let shiftArray3 = __atmp31 in
          let rec loop s p =
            let r = if p < plen
                    then
                      (if s < slen
                       then
                         let __atmp37 = 
                           let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_11_16" in 
                           let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                           let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                           let _ = if (!callflag) then fprintf outch ("s:%d\t") ((s)) in 
                           let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) in 
                           let _ = if (!callflag) then fprintf outch ("\n") in 
                           str s in
                         let __atmp38 = 
                           let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_19_24" in 
                           let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                           let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                           let _ = if (!callflag) then fprintf outch ("s:%d\t") ((s)) in 
                           let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) in 
                           let _ = if (!callflag) then fprintf outch ("__atmp37:%d\t") ((__atmp37)) in 
                           let _ = if (!callflag) then fprintf outch ("\n") in 
                           pat p in
                         (if __atmp37 = __atmp38
                          then
                            let __atmp48 = s + 1 in
                            let __atmp50 = p + 1 in 
                              let _ = if (!callflag) then fprintf outch ("env:%s\t") "25_10_26" in 
                              let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                              let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                              let _ = if (!callflag) then fprintf outch ("s:%d\t") ((s)) in 
                              let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp37:%d\t") ((__atmp37)) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp38:%d\t") ((__atmp38)) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp48:%d\t") ((__atmp48)) in 
                              let _ = if (!callflag) then fprintf outch ("__atmp50:%d\t") ((__atmp50)) in 
                              let _ = if (!callflag) then fprintf outch ("\n") in 
                              loop __atmp48 __atmp50
                          else
                            if p = 0
                            then
                              (let __atmp46 = s + 1 in 
                                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "28_12_24" in 
                                 let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                                 let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                                 let _ = if (!callflag) then fprintf outch ("s:%d\t") ((s)) in 
                                 let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) in 
                                 let _ = if (!callflag) then fprintf outch ("__atmp37:%d\t") ((__atmp37)) in 
                                 let _ = if (!callflag) then fprintf outch ("__atmp38:%d\t") ((__atmp38)) in 
                                 let _ = if (!callflag) then fprintf outch ("__atmp46:%d\t") ((__atmp46)) in 
                                 let _ = if (!callflag) then fprintf outch ("\n") in 
                                 loop __atmp46 p)
                            else
                              (let __atmp43 = p - 1 in
                               let __atmp42 = 
                                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "30_20_37" in 
                                 let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                                 let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                                 let _ = if (!callflag) then fprintf outch ("s:%d\t") ((s)) in 
                                 let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) in 
                                 let _ = if (!callflag) then fprintf outch ("__atmp37:%d\t") ((__atmp37)) in 
                                 let _ = if (!callflag) then fprintf outch ("__atmp38:%d\t") ((__atmp38)) in 
                                 let _ = if (!callflag) then fprintf outch ("__atmp43:%d\t") ((__atmp43)) in 
                                 let _ = if (!callflag) then fprintf outch ("\n") in 
                                 shiftArray3 __atmp43 in
                               let __atmp41 = __atmp42 + 1 in 
                                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "30_12_42" in 
                                 let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
                                 let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
                                 let _ = if (!callflag) then fprintf outch ("s:%d\t") ((s)) in 
                                 let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) in 
                                 let _ = if (!callflag) then fprintf outch ("__atmp37:%d\t") ((__atmp37)) in 
                                 let _ = if (!callflag) then fprintf outch ("__atmp38:%d\t") ((__atmp38)) in 
                                 let _ = if (!callflag) then fprintf outch ("__atmp43:%d\t") ((__atmp43)) in 
                                 let _ = if (!callflag) then fprintf outch ("__atmp42:%d\t") ((__atmp42)) in 
                                 let _ = if (!callflag) then fprintf outch ("__atmp41:%d\t") ((__atmp41)) in 
                                 let _ = if (!callflag) then fprintf outch ("\n") in 
                                 loop s __atmp41))
                       else (-1))
                    else s - plen
               in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
            in let _ = if (!callflag) then fprintf outch ("s:%d\t") ((s)) 
            in let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) 
            in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
            in let _ = if (!callflag) then fprintf outch ("\n") in r in
          let __atmp52 = 0 in
          let __atmp53 = 0 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "34_4_12" in 
            let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) in 
            let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp52:%d\t") ((__atmp52)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp53:%d\t") ((__atmp53)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loop __atmp52
                                                                  __atmp53
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "kmpMatch" 
  in let _ = if (!callflag) then fprintf outch ("slen:%d\t") ((slen)) 
  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("str:"); fprintf outch ("str_0#%d,") ((0)); 
  (try fprintf outch ("str_r#%d\t") ((str 0)) with _->(fprintf outch ("	"))); 
  (callflag := true))  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("str:"); fprintf outch ("str_0#%d,") (((0 + 1))); 
  (try fprintf outch ("str_r#%d\t") ((str (0 + 1))) with _->(fprintf outch ("	"))); 
  (callflag := true)) 
  in let _ = if (!callflag) then fprintf outch ("plen:%d\t") ((plen)) 
  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("pat:"); fprintf outch ("pat_0#%d,") ((0)); 
  (try fprintf outch ("pat_r#%d\t") ((pat 0)) with _->(fprintf outch ("	"))); 
  (callflag := true))  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("pat:"); fprintf outch ("pat_0#%d,") (((0 + 1))); 
  (try fprintf outch ("pat_r#%d\t") ((pat (0 + 1))) with _->(fprintf outch ("	"))); 
  (callflag := true))  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("pat:"); fprintf outch ("pat_0#%d,") ((((0 - 1) + 1))); 
  (try fprintf outch ("pat_r#%d\t") ((pat ((0 - 1) + 1))) with _->(fprintf outch ("	"))); 
  (callflag := true))  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("pat:"); fprintf outch ("pat_0#%d,") ((1)); 
  (try fprintf outch ("pat_r#%d\t") ((pat 1)) with _->(fprintf outch ("	"))); 
  (callflag := true))  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("pat:"); fprintf outch ("pat_0#%d,") (((1 + 1))); 
  (try fprintf outch ("pat_r#%d\t") ((pat (1 + 1))) with _->(fprintf outch ("	"))); 
  (callflag := true)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n a m b =
  let r = let __atmp54 = make_array n a in
          let array1 = __atmp54 in
          let __atmp55 = make_array m b in
          let array2 = __atmp55 in
          let __atmp57 = n > 0 in
          let __atmp59 = m > 0 in
          if __atmp57 && __atmp59
          then
            (
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "39_22_48" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("a:%d\t") ((a)) in 
             let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
             let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp57:%d\t") (if (__atmp57) then 1 else 0) in 
             let _ = if (!callflag) then fprintf outch ("__atmp59:%d\t") (if (__atmp59) then 1 else 0) in 
             let _ = if (!callflag) then fprintf outch ("\n") in kmpMatch n
                                                                   array1 m
                                                                   array2;
             ())
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("a:%d\t") ((a)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 