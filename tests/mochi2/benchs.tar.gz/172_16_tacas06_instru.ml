open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x y (i : int) (j : int) =
  let r = if x <> 0
          then
            let __atmp6 = x - 1 in
            let __atmp8 = y - 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_2_22" in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp6
                                                                    __atmp8 i
                                                                    j
          else if i = j then assert (y = 0) else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main i j =
  let r = let x = i in
          let y = j in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_1_13" in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loop x y i j
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp10 = 10 in
  let __atmp11 = 10 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_8_18" in 
    let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp10
                                                          __atmp11
let _ =
  let __atmp12 = 9 in
  let __atmp13 = 9 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp12
                                                          __atmp13
let _ =
  let __atmp14 = 3 in
  let __atmp15 = (-3) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_8_19" in 
    let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp14
                                                          __atmp15
let _ =
  let __atmp16 = 0 in
  let __atmp17 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp16
                                                          __atmp17
let _ = close_out outch 