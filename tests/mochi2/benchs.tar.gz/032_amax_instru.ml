open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let f l i =
  let r = (let __atmp2 = 0 <= i in
           let __atmp4 = i < l in assert (__atmp2 && __atmp4));
          l - i
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("l:%d\t") ((l)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec array_max (n : int) i (a : int -> int) (m : int) =
  let r = if i >= n
          then m
          else
            (let __atmp6 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_12_15" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
               let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in a i in
             let x = __atmp6 in
             let __atmp8 = if x > m then x else m in
             let z = __atmp8 in
             let __atmp9 = i + 1 in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_2_23" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
               let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
               let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in array_max
                                                                    n __atmp9
                                                                    a z)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "array_max" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = for ith = min([0]) to max([n]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("a:"); 
     fprintf outch ("a_0#%d,") ((ith));  
     (try fprintf outch ("a_r#%d\t") ((a ith)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("a:"); fprintf outch ("a_0#%d,") ((i)); 
  (try fprintf outch ("a_r#%d\t") ((a i)) with _->(fprintf outch ("	"))); 
  (callflag := true))  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("a:"); fprintf outch ("a_0#%d,") (((i + 1))); 
  (try fprintf outch ("a_r#%d\t") ((a (i + 1))) with _->(fprintf outch ("	"))); 
  (callflag := true)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main (n : int) (ith : int) =
  let r = let __atmp11 = f n in
          let a = __atmp11 in
          let __atmp12 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_9_26" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("ith:%d\t") ((ith)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in array_max n 0
                                                                  a 0 in
          let m = __atmp12 in
          let __atmp16 = ith >= 0 in
          let __atmp18 = ith < n in
          if __atmp16 && __atmp18
          then
            let __atmp20 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_10_15" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("ith:%d\t") ((ith)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
              let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") (if (__atmp16) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") (if (__atmp18) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("\n") in a ith in
            assert (__atmp20 <= m)
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("ith:%d\t") ((ith)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp21 = 2 in
  let __atmp22 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp21
                                                          __atmp22
let _ = close_out outch 