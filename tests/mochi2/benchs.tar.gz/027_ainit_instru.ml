open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let f n i =
  let r = (let __atmp2 = 0 <= i in
           let __atmp4 = i < n in assert (__atmp2 && __atmp4));
          0
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let update (n : int) (i : int) (x : int) a (j : int) =
  let r = let __atmp7 = i - 1 in
          let __atmp6 = j > __atmp7 in
          let __atmp9 = j <= i in
          if __atmp6 && __atmp9
          then x
          else 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_2_5" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") (if (__atmp6) then 1 else 0) in 
            let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") (if (__atmp9) then 1 else 0) in 
            let _ = if (!callflag) then fprintf outch ("\n") in a j
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "update" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = for j = min([(i - 1);  0]) to max([i;  n]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("a:"); 
     fprintf outch ("a_0#%d,") ((j));  
     (try fprintf outch ("a_r#%d\t") ((a j)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec init (x : int) i n (a : int -> int) =
  let r = if i >= n
          then a
          else
            (let __atmp11 = update n i x a in
             let u = __atmp11 in
             let __atmp12 = i + 1 in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_5_21" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in init x
                                                                    __atmp12
                                                                    n u)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "init" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = for ith = min([0;  (i - 1)]) to max([n;  i]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("a:"); 
     fprintf outch ("a_0#%d,") ((ith));  
     (try fprintf outch ("a_r#%d\t") ((a ith)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = for ith = min([0;  (i - 1)]) to max([n;  i]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("r:"); 
     fprintf outch ("r_0#%d,") ((ith));  
     (try fprintf outch ("r_r#%d\t") ((r ith)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main m ith x =
  let r = let __atmp14 = f m in
          let a = __atmp14 in
          let __atmp15 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_9_21" in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("ith:%d\t") ((ith)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in init x 0 m a in
          let y = __atmp15 in
          let __atmp18 = ith >= 0 in
          let __atmp20 = ith < m in
          if __atmp18 && __atmp20
          then
            let __atmp22 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_10_15" in 
              let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
              let _ = if (!callflag) then fprintf outch ("ith:%d\t") ((ith)) in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") (if (__atmp18) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") (if (__atmp20) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("\n") in y ith in
            assert (__atmp22 >= x)
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("ith:%d\t") ((ith)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp23 = 3 in
  let __atmp24 = 1 in
  let __atmp25 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "26_8_18" in 
    let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") ((__atmp24)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp23
                                                          __atmp24 __atmp25
let _ = close_out outch 