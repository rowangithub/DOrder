open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopc i n =
  let r = if i < n
          then
            let __atmp2 = i + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_2_15" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopc
                                                                    __atmp2 n
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopc" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopb i n =
  let r = if i < n
          then
            (assert (1 <= i);
             (let __atmp5 = i + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_2_15" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                    __atmp5 n))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopb" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopa k l n =
  let r = if k < n
          then
            (
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_3_12" in 
             let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
             let _ = if (!callflag) then fprintf outch ("l:%d\t") ((l)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopb l n;
             
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_2_11" in 
             let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
             let _ = if (!callflag) then fprintf outch ("l:%d\t") ((l)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopc l n;
             (let __atmp10 = k + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_2_17" in 
                let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
                let _ = if (!callflag) then fprintf outch ("l:%d\t") ((l)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp10
                                                                    l n))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("l:%d\t") ((l)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main l n =
  let r = if l > 0
          then
            let __atmp14 = 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_2_13" in 
              let _ = if (!callflag) then fprintf outch ("l:%d\t") ((l)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp14
                                                                    l n
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("l:%d\t") ((l)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp15 = 2 in
  let __atmp16 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp15
                                                          __atmp16
let _ =
  let __atmp17 = (-2) in
  let __atmp18 = (-3) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "25_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp17
                                                          __atmp18
let _ = close_out outch 