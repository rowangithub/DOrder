open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let make_array n = let r = n 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "make_array" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let arraysize src = let r = src 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "arraysize" 
  in let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let update des i x =
  let r = let __atmp2 = 0 <= i in
          let __atmp4 = i < des in assert (__atmp2 && __atmp4)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "update" 
  in let _ = if (!callflag) then fprintf outch ("des:%d\t") ((des)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let sub src i =
  let r = (let __atmp6 = 0 <= i in
           let __atmp8 = i < src in assert (__atmp6 && __atmp8));
          0
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "sub" 
  in let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec bcopy_aux src des i m =
  let r = if i >= m
          then ()
          else
            ((let __atmp12 = 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_19_30" in 
                let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) in 
                let _ = if (!callflag) then fprintf outch ("des:%d\t") ((des)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in sub src i in
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_6_30" in 
                let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) in 
                let _ = if (!callflag) then fprintf outch ("des:%d\t") ((des)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in update
                                                                    des i
                                                                    __atmp12);
             (let __atmp10 = i + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_6_31" in 
                let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) in 
                let _ = if (!callflag) then fprintf outch ("des:%d\t") ((des)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in bcopy_aux
                                                                    src des
                                                                    __atmp10
                                                                    m))
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "bcopy_aux" 
  in let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) 
  in let _ = if (!callflag) then fprintf outch ("des:%d\t") ((des)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let bcopy src des =
  let r = let __atmp13 = 0 in
          let __atmp14 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_40_55" in 
            let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) in 
            let _ = if (!callflag) then fprintf outch ("des:%d\t") ((des)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in arraysize src in
           let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_20_55" in 
            let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) in 
            let _ = if (!callflag) then fprintf outch ("des:%d\t") ((des)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in bcopy_aux src
                                                                  des
                                                                  __atmp13
                                                                  __atmp14
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "bcopy" 
  in let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) 
  in let _ = if (!callflag) then fprintf outch ("des:%d\t") ((des)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n m =
  let r = let __atmp15 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_15_27" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in make_array n in
          let array1 = __atmp15 in
          let __atmp16 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_15_27" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
            let _ = if (!callflag) then fprintf outch ("array1:%d\t") ((array1)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in make_array m in
          let array2 = __atmp16 in
          if n <= m
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_15_34" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
            let _ = if (!callflag) then fprintf outch ("array1:%d\t") ((array1)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
            let _ = if (!callflag) then fprintf outch ("array2:%d\t") ((array2)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in bcopy array1
                                                                  array2
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 