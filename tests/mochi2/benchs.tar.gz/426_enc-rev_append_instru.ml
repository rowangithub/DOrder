open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec append x y =
  let r = if x = 0
          then y
          else
            (let __atmp3 = 1 in
             let __atmp5 = x - 1 in
             let __atmp4 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_8_24" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in append
                                                                    __atmp5 y in
             __atmp3 + __atmp4)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "append" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec rev n =
  let r = if n = 0
          then 0
          else
            (let __atmp10 = n - 1 in
             let __atmp9 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_14_27" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in rev
                                                                    __atmp10 in
             let __atmp12 = 1 in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_7_29" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in append
                                                                    __atmp9
                                                                    __atmp12)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "rev" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n m =
  let r = (let __atmp17 = 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_10_15" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in rev n in
           assert (__atmp17 = n));
          (let __atmp14 = 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_10_20" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in append n m in
           let __atmp15 = n + m in assert (__atmp14 = __atmp15))
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 