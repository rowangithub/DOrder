open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let f n k =
  let r = if n >= 0
          then ()
          else
            (let __atmp3 = 0 in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_35_38" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in k __atmp3)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = for v0 = min([n-1]) to max([n+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("k:"); 
     fprintf outch ("k_0#%d,") ((v0));  
     (try fprintf outch ("k_r#%d\t") ((k v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let g n = let r = assert (n = 0) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "g" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_13_18" in 
    let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in f n g 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 