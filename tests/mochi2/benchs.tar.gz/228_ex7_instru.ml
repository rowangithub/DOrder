open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop i len y =
  let r = if i < y
          then
            let __atmp6 =
              let __atmp3 = 0 <= i in
              let __atmp5 = i < len in assert (__atmp3 && __atmp5) in
            let _ = __atmp6 in
            let __atmp7 = i + 1 in
            let i = __atmp7 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_2_14" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("len:%d\t") ((len)) in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop i len
                                                                    y
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("len:%d\t") ((len)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main x y =
  let r = let __atmp10 = x < 0 in
          let __atmp13 = y < 0 in
          let __atmp15 = y > x in
          let __atmp12 = __atmp13 || __atmp15 in
          if __atmp10 || __atmp12
          then ()
          else
            (let len = x in
             let __atmp16 = 0 in
             let i = __atmp16 in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_3_15" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") (if (__atmp10) then 1 else 0) in 
               let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") (if (__atmp13) then 1 else 0) in 
               let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") (if (__atmp15) then 1 else 0) in 
               let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") (if (__atmp12) then 1 else 0) in 
               let _ = if (!callflag) then fprintf outch ("len:%d\t") ((len)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in loop i len
                                                                    y)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp17 = (-1) in
  let __atmp18 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp17
                                                          __atmp18
let _ =
  let __atmp19 = 4 in
  let __atmp20 = 4 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp19
                                                          __atmp20
let _ =
  let __atmp21 = 5 in
  let __atmp22 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp21
                                                          __atmp22
let _ =
  let __atmp23 = 2 in
  let __atmp24 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") ((__atmp24)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp23
                                                          __atmp24
let _ = close_out outch 