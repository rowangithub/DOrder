open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let main n lda =
  let r = if n < lda
          then (if 0 <= n then (assert (0 <= n); assert (n < lda)) else ())
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("lda:%d\t") ((lda)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp7 = 2 in
  let __atmp8 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp7 __atmp8
let _ =
  let __atmp9 = (-2) in
  let __atmp10 = (-3) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp9 __atmp10
let _ = close_out outch 