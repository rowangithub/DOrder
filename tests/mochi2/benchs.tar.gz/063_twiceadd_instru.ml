open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let add x1 x2 = let r = x1 + x2 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "add" 
  in let _ = if (!callflag) then fprintf outch ("x1:%d\t") ((x1)) 
  in let _ = if (!callflag) then fprintf outch ("x2:%d\t") ((x2)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let twice x (n : int) (f : int -> int) =
  let r = assert (x >= 0);
          (let __atmp1 = 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_55_60" in 
             let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in f x in
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_53_60" in 
             let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp1:%d\t") ((__atmp1)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in f __atmp1)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "twice" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("f:"); (try fprintf outch ("f_0#%d,") (((f x))) with _->()); 
  (try fprintf outch ("f_r#%d\t") ((f (f x))) with _->(fprintf outch ("	"))); 
  (callflag := true))  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("f:"); fprintf outch ("f_0#%d,") ((x)); 
  (try fprintf outch ("f_r#%d\t") ((f x)) with _->(fprintf outch ("	"))); 
  (callflag := true)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp7 = add n in
          let __atmp5 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_21_38" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in twice 0 n
                                                                  __atmp7 in
          let __atmp8 = 2 * n in assert (__atmp5 >= __atmp8)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp10 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp10
let _ = close_out outch 