open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let add x1 x2 = let r = x1 + x2 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "add" 
  in let _ = if (!callflag) then fprintf outch ("x1:%d\t") ((x1)) 
  in let _ = if (!callflag) then fprintf outch ("x2:%d\t") ((x2)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec repeat (k : int) (x : int) (n : int) (f : int -> int) =
  let r = if k <= 0
          then x
          else
            (let __atmp4 = k - 1 in
             let __atmp3 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_25_47" in 
               let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in repeat
                                                                    __atmp4 x
                                                                    n f in
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_23_47" in 
               let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in f __atmp3)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "repeat" 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("f:"); fprintf outch ("f_0#%d,") ((x)); 
  (try fprintf outch ("f_r#%d\t") ((f x)) with _->(fprintf outch ("	"))); 
  (callflag := true)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n k =
  let r = let __atmp7 = n >= 0 in
          let __atmp9 = k > 0 in
          if __atmp7 && __atmp9
          then
            let __atmp14 = add n in
            let __atmp12 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_47_67" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") (if (__atmp7) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") (if (__atmp9) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("\n") in repeat k 0
                                                                    n
                                                                    __atmp14 in
            assert (__atmp12 >= n)
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp15 = 2 in
  let __atmp16 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp15
                                                          __atmp16
let _ = close_out outch 