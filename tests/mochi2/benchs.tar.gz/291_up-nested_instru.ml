open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopa i j n =
  let r = if j <= n
          then
            (if i >= 0
             then
               let __atmp6 = j + 1 in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_5_20" in 
                 let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                 let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                 let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 loopa i __atmp6 n
             else 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_7_18" in 
               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
               let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in loopa i j
                                                                    n)
          else assert (i >= 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main j n =
  let r = let __atmp8 = 0 in
          let i = __atmp8 in
          let __atmp9 = 0 in
          let k = __atmp9 in
          if j <= n
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_2_13" in 
            let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopa i j n
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp11 = 3 in
  let __atmp12 = 6 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "36_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp11
                                                          __atmp12
let _ =
  let __atmp13 = 4 in
  let __atmp14 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "37_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp13
                                                          __atmp14
let _ =
  let __atmp15 = (-1) in
  let __atmp16 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "38_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp15
                                                          __atmp16
let _ = close_out outch 