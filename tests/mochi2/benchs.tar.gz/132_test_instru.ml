open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let f (x : int) = let r = x 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main x =
  let r = let __atmp2 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_9_12" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f x in
          assert (__atmp2 >= x)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp3 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp3
let _ =
  let __atmp4 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp4
let _ = close_out outch 