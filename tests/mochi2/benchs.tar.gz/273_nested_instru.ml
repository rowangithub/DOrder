open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopb i n =
  let r = if i < n
          then
            let __atmp2 = i + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_2_15" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                    __atmp2 n
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopb" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopa k n =
  let r = if k < n
          then
            ((let __atmp9 = 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_3_12" in 
                let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                    __atmp9 n);
             (let __atmp7 = k + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_2_15" in 
                let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp7 n))
          else assert (k >= 1)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp10 = 1 in
          let k = __atmp10 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_1_10" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopa k n
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp11 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp11
let _ =
  let __atmp12 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp12
let _ = close_out outch 