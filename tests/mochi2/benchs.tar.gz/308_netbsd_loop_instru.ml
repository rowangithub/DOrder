open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop glob2_p_off glob2_pathlim_off maxpathlen =
  let r = if glob2_p_off <= glob2_pathlim_off
          then
            let __atmp4 = assert (0 <= glob2_p_off) in
            let _ = __atmp4 in
            let __atmp8 =
              let __atmp6 = maxpathlen + 1 in assert (glob2_p_off < __atmp6) in
            let _ = __atmp8 in
            let __atmp9 = glob2_p_off + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_2_51" in 
              let _ = if (!callflag) then fprintf outch ("glob2_p_off:%d\t") ((glob2_p_off)) in 
              let _ = if (!callflag) then fprintf outch ("glob2_pathlim_off:%d\t") ((glob2_pathlim_off)) in 
              let _ = if (!callflag) then fprintf outch ("maxpathlen:%d\t") ((maxpathlen)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp9
                                                                    glob2_pathlim_off
                                                                    maxpathlen
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("glob2_p_off:%d\t") ((glob2_p_off)) 
  in let _ = if (!callflag) then fprintf outch ("glob2_pathlim_off:%d\t") ((glob2_pathlim_off)) 
  in let _ = if (!callflag) then fprintf outch ("maxpathlen:%d\t") ((maxpathlen)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main maxpathlen =
  let r = if maxpathlen > 0
          then
            let __atmp13 = 0 in
            let pathbuf_off = __atmp13 in
            let __atmp16 = maxpathlen + 1 in
            let __atmp15 = pathbuf_off + __atmp16 in
            let __atmp14 = __atmp15 - 1 in
            let bound_off = __atmp14 in
            let glob2_pathbuf_off = pathbuf_off in
            let glob2_pathlim_off = bound_off in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_2_53" in 
              let _ = if (!callflag) then fprintf outch ("maxpathlen:%d\t") ((maxpathlen)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
              let _ = if (!callflag) then fprintf outch ("pathbuf_off:%d\t") ((pathbuf_off)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
              let _ = if (!callflag) then fprintf outch ("bound_off:%d\t") ((bound_off)) in 
              let _ = if (!callflag) then fprintf outch ("glob2_pathbuf_off:%d\t") ((glob2_pathbuf_off)) in 
              let _ = if (!callflag) then fprintf outch ("glob2_pathlim_off:%d\t") ((glob2_pathlim_off)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    glob2_pathbuf_off
                                                                    glob2_pathlim_off
                                                                    maxpathlen
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("maxpathlen:%d\t") ((maxpathlen)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp19 = 10 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_8_15" in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp19
let _ =
  let __atmp20 = 9 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp20
let _ =
  let __atmp21 = (-4) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp21
let _ = close_out outch 