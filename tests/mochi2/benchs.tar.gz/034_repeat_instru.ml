open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let succ x = let r = let __atmp1 = 1 in x + __atmp1 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "succ" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec repeat (f : int -> int) n s =
  let r = if n = 0
          then s
          else
            (let __atmp5 = n - 1 in
             let __atmp4 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_6_24" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("s:%d\t") ((s)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in repeat f
                                                                    __atmp5 s in
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_4_24" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("s:%d\t") ((s)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in f __atmp4)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "repeat" 
  in let _ = for s = min([min[]]) to max([s]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("f:"); 
     fprintf outch ("f_0#%d,") ((s));  
     (try fprintf outch ("f_r#%d\t") ((f s)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("s:%d\t") ((s)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp8 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_21_36" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in repeat succ n
                                                                  0 in
          assert (__atmp8 >= n)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp10 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp10
let _ = close_out outch 