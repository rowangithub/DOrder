open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let make_array n = let r = n 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "make_array" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let arraysize src = let r = src 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "arraysize" 
  in let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let update des i x =
  let r = let __atmp2 = 0 <= i in
          let __atmp4 = i < des in assert (__atmp2 && __atmp4)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "update" 
  in let _ = if (!callflag) then fprintf outch ("des:%d\t") ((des)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let sub src i =
  let r = (let __atmp6 = 0 <= i in
           let __atmp8 = i < src in assert (__atmp6 && __atmp8));
          0
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "sub" 
  in let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec bs_aux key vec l u =
  let r = if u < l
          then (-1)
          else
            (let __atmp12 = u - l in
             let __atmp11 = __atmp12 / 2 in
             let __atmp10 = l + __atmp11 in
             let m = __atmp10 in
             let __atmp14 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_12_21" in 
               let _ = if (!callflag) then fprintf outch ("key:%d\t") ((key)) in 
               let _ = if (!callflag) then fprintf outch ("vec:%d\t") ((vec)) in 
               let _ = if (!callflag) then fprintf outch ("l:%d\t") ((l)) in 
               let _ = if (!callflag) then fprintf outch ("u:%d\t") ((u)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
               let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in sub vec m in
             let x = __atmp14 in
             if x < key
             then
               let __atmp19 = m + 1 in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_22_44" in 
                 let _ = if (!callflag) then fprintf outch ("key:%d\t") ((key)) in 
                 let _ = if (!callflag) then fprintf outch ("vec:%d\t") ((vec)) in 
                 let _ = if (!callflag) then fprintf outch ("l:%d\t") ((l)) in 
                 let _ = if (!callflag) then fprintf outch ("u:%d\t") ((u)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
                 let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
                 let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 bs_aux key vec __atmp19 u
             else
               if x > key
               then
                 (let __atmp17 = m - 1 in 
                    let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_27_49" in 
                    let _ = if (!callflag) then fprintf outch ("key:%d\t") ((key)) in 
                    let _ = if (!callflag) then fprintf outch ("vec:%d\t") ((vec)) in 
                    let _ = if (!callflag) then fprintf outch ("l:%d\t") ((l)) in 
                    let _ = if (!callflag) then fprintf outch ("u:%d\t") ((u)) in 
                    let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                    let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
                    let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
                    let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                    let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
                    let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                    let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
                    let _ = if (!callflag) then fprintf outch ("\n") in 
                    bs_aux key vec l __atmp17)
               else m)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "bs_aux" 
  in let _ = if (!callflag) then fprintf outch ("key:%d\t") ((key)) 
  in let _ = if (!callflag) then fprintf outch ("vec:%d\t") ((vec)) 
  in let _ = if (!callflag) then fprintf outch ("l:%d\t") ((l)) 
  in let _ = if (!callflag) then fprintf outch ("u:%d\t") ((u)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let bsearch key vec =
  let r = let __atmp21 = 0 in
          let __atmp23 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_40_53" in 
            let _ = if (!callflag) then fprintf outch ("key:%d\t") ((key)) in 
            let _ = if (!callflag) then fprintf outch ("vec:%d\t") ((vec)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in arraysize vec in
          let __atmp22 = __atmp23 - 1 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_22_58" in 
            let _ = if (!callflag) then fprintf outch ("key:%d\t") ((key)) in 
            let _ = if (!callflag) then fprintf outch ("vec:%d\t") ((vec)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in bs_aux key
                                                                  vec
                                                                  __atmp21
                                                                  __atmp22
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "bsearch" 
  in let _ = if (!callflag) then fprintf outch ("key:%d\t") ((key)) 
  in let _ = if (!callflag) then fprintf outch ("vec:%d\t") ((vec)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n m =
  let r = let __atmp25 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_11_23" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in make_array n in
          let v1 = __atmp25 in
          let __atmp26 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_11_23" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
            let _ = if (!callflag) then fprintf outch ("v1:%d\t") ((v1)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in make_array m in
          let v2 = __atmp26 in
          let __atmp28 = 0 <= n in
          let __atmp30 = n = m in
          if __atmp28 && __atmp30
          then
            (
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "22_23_36" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
             let _ = if (!callflag) then fprintf outch ("v1:%d\t") ((v1)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
             let _ = if (!callflag) then fprintf outch ("v2:%d\t") ((v2)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") (if (__atmp28) then 1 else 0) in 
             let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") (if (__atmp30) then 1 else 0) in 
             let _ = if (!callflag) then fprintf outch ("\n") in bsearch v1
                                                                   v2;
             ())
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 