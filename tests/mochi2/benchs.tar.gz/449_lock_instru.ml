open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let lock st = let r = assert (st = 0); 1 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "lock" 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let unlock st = let r = assert (st = 1); 0 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "unlock" 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let f n st =
  let r = (if n > 0
           then 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_32_41" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in lock st
           else st : int )
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let g n st =
  let r = (if n > 0
           then 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_33_44" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in unlock st
           else st : int )
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "g" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("st:%d\t") ((st)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp7 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_26_33" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f n 0 in
          let __atmp6 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_21_34" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in g n __atmp7 in
          assert (__atmp6 = 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 