open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec fib n =
  let r = if n < 2
          then 1
          else
            (let __atmp4 = n - 1 in
             let __atmp3 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_4_13" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in fib
                                                                    __atmp4 in
             let __atmp7 = n - 2 in
             let __atmp6 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_16_25" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in fib
                                                                    __atmp7 in
             __atmp3 + __atmp6)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "fib" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp10 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_15_20" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in fib n in
          assert (n <= __atmp10)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 