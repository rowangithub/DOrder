open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x =
  let r = let __atmp1 = () in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_17_24" in 
            let _ = if (!callflag) then fprintf outch ("\n") in loop __atmp1
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec zip x y =
  let r = if x = 0
          then
            (if y = 0
             then 0
             else
               (let __atmp15 = () in 
                  let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_9_16" in 
                  let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                  let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                  let _ = if (!callflag) then fprintf outch ("\n") in 
                  loop __atmp15))
          else
            if y = 0
            then
              (let __atmp12 = () in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_9_16" in 
                 let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                 let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 loop __atmp12)
            else
              (let __atmp6 = 1 in
               let __atmp8 = x - 1 in
               let __atmp10 = y - 1 in
               let __atmp7 = 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_13_28" in 
                 let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                 let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 zip __atmp8 __atmp10 in
               __atmp6 + __atmp7)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "zip" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp17 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_10_17" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in zip n n in
          assert (__atmp17 = n)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 