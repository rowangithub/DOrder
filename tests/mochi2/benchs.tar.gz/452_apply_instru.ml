open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let apply f x =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_16_19" in 
    let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in f x 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "apply" 
  in let _ = for v0 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("f:"); 
     fprintf outch ("f_0#%d,") ((v0));  
     (try fprintf outch ("f_r#%d\t") ((f v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let g y z = let r = assert (y = z) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "g" 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec k n =
  let r = (let __atmp4 = g n in 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_14_27" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in apply
                                                                   __atmp4 n);
          (let __atmp2 = n + 1 in 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_29_35" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in k __atmp2)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "k" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main i =
  let r = let __atmp5 = 0 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_13_16" in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in k __atmp5
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 