open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let make_array n i =
  let r = (let __atmp2 = 0 <= i in
           let __atmp4 = i < n in assert (__atmp2 && __atmp4));
          0
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "make_array" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec dotprod n v1 v2 i sum =
  let r = if i >= n
          then sum
          else
            ((let __atmp12 = i + 1 in
              let __atmp16 = 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_36_40" in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in v1 i in
              let __atmp15 = sum + __atmp16 in
              let __atmp17 = 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_43_47" in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in v2 i in
              let __atmp14 = __atmp15 + __atmp17 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_7_48" in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in dotprod n
                                                                    v1 v2
                                                                    __atmp12
                                                                    __atmp14);
             (let __atmp6 = i + 1 in
              let __atmp10 = 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_40_44" in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in v1 i in
              let __atmp9 = sum + __atmp10 in
              let __atmp11 = 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_47_51" in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in v2 i in
              let __atmp8 = __atmp9 + __atmp11 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_11_52" in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in dotprod n
                                                                    v1 v2
                                                                    __atmp6
                                                                    __atmp8))
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "dotprod" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = for v0 = min([n-1]) to max([n+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("v1:"); 
     fprintf outch ("v1_0#%d,") ((v0));  
     (try fprintf outch ("v1_r#%d\t") ((v1 v0)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = for v0 = min([n-1]) to max([n+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("v2:"); 
     fprintf outch ("v2_0#%d,") ((v0));  
     (try fprintf outch ("v2_r#%d\t") ((v2 v0)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n m z =
  let r = let __atmp18 = make_array n in
          let v1 = __atmp18 in
          let __atmp19 = make_array n in
          let v2 = __atmp19 in
          if z = 0
          then
            (
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_14_33" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
             let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in dotprod n v1
                                                                   v2 z z;
             ())
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 