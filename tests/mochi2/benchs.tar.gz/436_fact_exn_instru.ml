open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec fact n exn =
  let r = if n <= 0
          then
            let __atmp9 = 0 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_7_12" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in exn __atmp9
          else
            (let __atmp5 n =
               let r = if n = 0
                       then 1
                       else 
                         let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_37_42" in 
                         let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                         let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                         let _ = if (!callflag) then fprintf outch ("\n") in 
                         exn n
                  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "__atmp5" 
               in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
               in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
               in let _ = if (!callflag) then fprintf outch ("\n") in r in
             let exn = __atmp5 in
             let __atmp7 = n - 1 in
             let __atmp6 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_10_24" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in fact
                                                                    __atmp7
                                                                    exn in
             n * __atmp6)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "fact" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = for v0 = min([n-1]) to max([n+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("exn:"); 
     fprintf outch ("exn_0#%d,") ((v0));  
     (try fprintf outch ("exn_r#%d\t") ((exn v0)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let exn n = let r = assert false; 1 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "exn" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = if n > 0
          then
            (
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_8_18" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in fact n exn;
             ())
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 