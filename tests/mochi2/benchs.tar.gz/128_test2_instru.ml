open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let f x =
  let r = let __atmp3 = if x > 5 then 2 else 5 in
          let r = __atmp3 in assert (r = 2)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main x =
  let r = if x > 10
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_2_5" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f x
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp8 = 11 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_8_15" in 
    let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp8
let _ =
  let __atmp9 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp9
let _ = close_out outch 