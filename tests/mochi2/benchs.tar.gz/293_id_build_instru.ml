open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopb i j nlen =
  let r = if j < 8
          then
            ((let __atmp12 = nlen - 1 in
              let __atmp11 = __atmp12 - i in assert (0 <= __atmp11));
             (let __atmp7 = nlen - 1 in
              let __atmp6 = __atmp7 - i in assert (__atmp6 < nlen));
             (let __atmp3 = j + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_2_20" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                let _ = if (!callflag) then fprintf outch ("nlen:%d\t") ((nlen)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopb i
                                                                    __atmp3
                                                                    nlen))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopb" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("nlen:%d\t") ((nlen)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopa i nlen =
  let r = if i < nlen
          then
            ((let __atmp17 = 0 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_3_17" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("nlen:%d\t") ((nlen)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopb i
                                                                    __atmp17
                                                                    nlen);
             (let __atmp15 = i + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_2_18" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("nlen:%d\t") ((nlen)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp15
                                                                    nlen))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("nlen:%d\t") ((nlen)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main nlen =
  let r = let __atmp18 = 0 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_2_14" in 
            let _ = if (!callflag) then fprintf outch ("nlen:%d\t") ((nlen)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                  __atmp18
                                                                  nlen
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("nlen:%d\t") ((nlen)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp19 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp19
let _ =
  let __atmp20 = (-4) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp20
let _ = close_out outch 