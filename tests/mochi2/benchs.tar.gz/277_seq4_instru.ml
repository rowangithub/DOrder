open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopa i k n =
  let r = if i < n
          then
            let __atmp2 = i + 1 in
            let __atmp4 = k + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_15_34" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp2
                                                                    __atmp4 n
          else k
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopb i k n =
  let r = if i < n
          then
            let __atmp9 = assert (k > 0) in
            let __atmp11 = i + 1 in
            let __atmp13 = k - 1 in
            let __atmp10 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_32_49" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                    __atmp11
                                                                    __atmp13 in
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_15_52" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in __atmp10 n
          else k
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopb" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopc i k n =
  let r = if i < n
          then
            let __atmp16 = i + 1 in
            let __atmp18 = k - 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_15_36" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopc
                                                                    __atmp16
                                                                    __atmp18
                                                                    n
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopc" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n m =
  let r = let __atmp20 = 0 in
          let i = __atmp20 in
          let __atmp21 = 0 in
          let k = __atmp21 in
          let __atmp22 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_9_20" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopa i k n in
          let k = __atmp22 in
          let __atmp23 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_9_20" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopa i k m in
          let k = __atmp23 in
          let __atmp24 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_10_21" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopb i k m in
          let k = __atmp24 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_1_12" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") ((__atmp24)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopc i k n
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp25 = 2 in
  let __atmp26 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "22_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp25
                                                          __atmp26
let _ =
  let __atmp27 = 3 in
  let __atmp28 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "23_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp27
                                                          __atmp28
let _ =
  let __atmp29 = (-1) in
  let __atmp30 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") ((__atmp30)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp29
                                                          __atmp30
let _ =
  let __atmp31 = (-2) in
  let __atmp32 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "25_8_19" in 
    let _ = if (!callflag) then fprintf outch ("__atmp31:%d\t") ((__atmp31)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp32:%d\t") ((__atmp32)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp31
                                                          __atmp32
let _ =
  let __atmp33 = 2 in
  let __atmp34 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "26_8_19" in 
    let _ = if (!callflag) then fprintf outch ("__atmp33:%d\t") ((__atmp33)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp34:%d\t") ((__atmp34)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp33
                                                          __atmp34
let _ = close_out outch 