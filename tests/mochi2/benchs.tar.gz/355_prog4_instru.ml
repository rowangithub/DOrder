open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop b x y =
  let r = if x < 10
          then
            (if 0 <= b
             then
               let __atmp23 = x + 1 in
               let __atmp25 = y + 1 in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_3_21" in 
                 let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) in 
                 let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                 let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 loop b __atmp23 __atmp25
             else
               (let __atmp19 = x + 1 in
                let __atmp21 = y - 1 in 
                  let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_7_25" in 
                  let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) in 
                  let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                  let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                  let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
                  let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
                  let _ = if (!callflag) then fprintf outch ("\n") in 
                  loop b __atmp19 __atmp21))
          else
            (let __atmp4 = y = 0 in
             let __atmp8 = y >= 0 in
             let __atmp10 = b >= 0 in
             let __atmp7 = __atmp8 && __atmp10 in
             let __atmp13 = b <= (-1) in
             let __atmp15 = y <= 0 in
             let __atmp12 = __atmp13 && __atmp15 in
             let __atmp6 = __atmp7 || __atmp12 in assert (__atmp4 || __atmp6))
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main b =
  let r = let __atmp27 = 0 in
          let x = __atmp27 in
          let __atmp28 = 0 in
          let y = __atmp28 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_1_11" in 
            let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loop b x y
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp29 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp29
let _ =
  let __atmp30 = (-3) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") ((__atmp30)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp30
let _ = close_out outch 