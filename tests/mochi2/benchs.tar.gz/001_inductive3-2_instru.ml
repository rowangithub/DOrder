open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec f x =
  let r = if x < (-1)
          then
            let __atmp8 = (-2) in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_4_10" in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in f __atmp8
          else
            if x <= 1
            then
              (let __atmp5 = 2 * x in let __atmp7 = 1 in __atmp5 - __atmp7)
            else x
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp9 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_10_13" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f 0 in
          let v = __atmp9 in
          if n >= 2
          then
            let __atmp14 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_24_27" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
              let _ = if (!callflag) then fprintf outch ("v:%d\t") ((v)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in f n in
            assert (__atmp14 >= 0)
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp16 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp16
let _ = close_out outch 