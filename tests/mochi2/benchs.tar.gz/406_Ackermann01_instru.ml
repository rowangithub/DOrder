open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec ackermann m n =
  let r = if m = 0
          then let __atmp13 = 1 in n + __atmp13
          else
            if n = 0
            then
              (let __atmp10 = m - 1 in
               let __atmp12 = 1 in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_23_40" in 
                 let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                 let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 ackermann __atmp10 __atmp12)
            else
              (let __atmp5 = m - 1 in
               let __atmp8 = n - 1 in
               let __atmp7 = 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_24_43" in 
                 let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                 let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 ackermann m __atmp8 in
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_8_43" in 
                 let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                 let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 ackermann __atmp5 __atmp7)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "ackermann" 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main m n =
  let r = let __atmp15 = m < 0 in
          let __atmp17 = m > 3 in
          if __atmp15 || __atmp17
          then ()
          else
            (let __atmp20 = n < 0 in
             let __atmp22 = n > 23 in
             if __atmp20 || __atmp22
             then ()
             else
               (let __atmp24 = 
                  let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_17_30" in 
                  let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                  let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                  let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") (if (__atmp15) then 1 else 0) in 
                  let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") (if (__atmp17) then 1 else 0) in 
                  let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") (if (__atmp20) then 1 else 0) in 
                  let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") (if (__atmp22) then 1 else 0) in 
                  let _ = if (!callflag) then fprintf outch ("\n") in 
                  ackermann m n in
                let result = __atmp24 in
                let __atmp26 = m < 0 in
                let __atmp29 = n < 0 in
                let __atmp31 = result >= 0 in
                let __atmp28 = __atmp29 || __atmp31 in
                assert (__atmp26 || __atmp28)))
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp33 = 2 in
  let __atmp34 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp33:%d\t") ((__atmp33)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp34:%d\t") ((__atmp34)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp33
                                                          __atmp34
let _ =
  let __atmp35 = 3 in
  let __atmp36 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "25_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp35:%d\t") ((__atmp35)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp36:%d\t") ((__atmp36)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp35
                                                          __atmp36
let _ =
  let __atmp37 = (-2) in
  let __atmp38 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "26_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp37:%d\t") ((__atmp37)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp38:%d\t") ((__atmp38)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp37
                                                          __atmp38
let _ = close_out outch 