open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x y n =
  let r = let __atmp7 =
            if x <= n
            then let __atmp6 = 1 in y + __atmp6
            else
              (let __atmp3 = n + 1 in
               if x >= __atmp3
               then let __atmp5 = 1 in y - __atmp5
               else assert false) in
          let y = __atmp7 in
          if y < 0
          then
            (if n >= 0
             then
               (if y = (-1)
                then
                  let __atmp18 = 2 * n in
                  let __atmp17 = __atmp18 + 3 in assert (x < __atmp17)
                else ())
             else ())
          else
            (let __atmp10 = x + 1 in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_7_21" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
               let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp10
                                                                    y n)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp21 = 0 in
          let x = __atmp21 in
          let __atmp22 = 0 in
          let y = __atmp22 in
          if n < 0
          then ()
          else 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_2_12" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loop x y n
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp25 = 10 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "22_8_15" in 
    let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp25
let _ =
  let __atmp26 = 9 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "23_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp26
let _ =
  let __atmp27 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp27
let _ = close_out outch 