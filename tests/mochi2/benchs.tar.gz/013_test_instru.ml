open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let f (x : int) g h =
  let r = let __atmp1 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_22_27" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in h x in
           let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_20_27" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp1:%d\t") ((__atmp1)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in g __atmp1
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("g:"); (try fprintf outch ("g_0#%d,") (((h x))) with _->()); 
  (try fprintf outch ("g_r#%d\t") ((g (h x))) with _->(fprintf outch ("	"))); 
  (callflag := true))  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("h:"); fprintf outch ("h_0#%d,") ((x)); 
  (try fprintf outch ("h_r#%d\t") ((h x)) with _->(fprintf outch ("	"))); 
  (callflag := true)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let h (x : int) = let r = x 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "h" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let g y = let r = let __atmp2 = 1 in y + __atmp2 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "g" 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main a =
  let r = if a > 0
          then
            let __atmp6 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_10_17" in 
              let _ = if (!callflag) then fprintf outch ("a:%d\t") ((a)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in f a g h in
            assert (__atmp6 > 1)
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("a:%d\t") ((a)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp8 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp8
let _ =
  let __atmp9 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp9
let _ = close_out outch 