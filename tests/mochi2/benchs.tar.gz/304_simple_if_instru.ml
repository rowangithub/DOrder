open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop i m n =
  let r = if i < n
          then
            (if m > 0
             then
               let __atmp8 = 2 * i in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_6_20" in 
                 let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                 let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                 let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 loop __atmp8 m n
             else
               (let __atmp6 = 3 * i in 
                  let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_6_20" in 
                  let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                  let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                  let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                  let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
                  let _ = if (!callflag) then fprintf outch ("\n") in 
                  loop __atmp6 m n))
          else assert (i > 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main m n =
  let r = let __atmp10 = 1 in
          let i = __atmp10 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_2_12" in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loop i m n
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp11 = 1 in
  let __atmp12 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp11
                                                          __atmp12
let _ =
  let __atmp13 = 0 in
  let __atmp14 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp13
                                                          __atmp14
let _ =
  let __atmp15 = (-1) in
  let __atmp16 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp15
                                                          __atmp16
let _ = close_out outch 