open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x n =
  let r = if x < n
          then
            let __atmp5 = x + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_17_29" in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp5 n
          else if n > 0 then assert (x = n) else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp7 = 0 in
          let x = __atmp7 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_1_9" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loop x n
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp8 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp8
let _ =
  let __atmp9 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp9
let _ =
  let __atmp10 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp10
let _ = close_out outch 