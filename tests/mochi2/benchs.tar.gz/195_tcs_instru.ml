open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop (i : int) (j : int) x y =
  let r = if x = 0
          then (if i = j then assert (y = 0) else ())
          else
            (let __atmp3 = x - 1 in
             let __atmp5 = y - 1 in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_1_21" in 
               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
               let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in loop i j
                                                                    __atmp3
                                                                    __atmp5)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main i j =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_1_13" in 
    let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
    let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in loop i j i j 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp10 = 3 in
  let __atmp11 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp10
                                                          __atmp11
let _ =
  let __atmp12 = 2 in
  let __atmp13 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp12
                                                          __atmp13
let _ =
  let __atmp14 = 2 in
  let __atmp15 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp14
                                                          __atmp15
let _ =
  let __atmp16 = 5 in
  let __atmp17 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp16
                                                          __atmp17
let _ = close_out outch 