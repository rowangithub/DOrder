open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x i =
  let r = if i < 0
          then x
          else
            if x < 1
            then
              (let __atmp13 = x - 1 in
               let __atmp15 = i - 1 in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_4_24" in 
                 let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                 let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 loop __atmp13 __atmp15)
            else
              if x > 2
              then
                (let __atmp11 = i - 1 in 
                   let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_4_18" in 
                   let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                   let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                   let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
                   let _ = if (!callflag) then fprintf outch ("\n") in 
                   loop x __atmp11)
              else
                (let __atmp7 = 3 - x in
                 let __atmp9 = i - 1 in 
                   let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_4_24" in 
                   let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                   let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                   let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                   let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
                   let _ = if (!callflag) then fprintf outch ("\n") in 
                   loop __atmp7 __atmp9)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = (let __atmp22 = 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_10_18" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loop 3 n in
           assert (__atmp22 >= 3));
          (let __atmp18 = 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_10_18" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loop 1 n in
           assert (__atmp18 >= 0))
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 