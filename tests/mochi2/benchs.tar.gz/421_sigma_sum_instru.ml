open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec sum n =
  let r = if n <= 0
          then 0
          else
            (let __atmp4 = n - 1 in
             let __atmp3 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_11_20" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in sum
                                                                    __atmp4 in
             n + __atmp3)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "sum" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec sigma f n =
  let r = if n <= 0
          then 0
          else
            (let __atmp8 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_7_10" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in f n in
             let __atmp10 = n - 1 in
             let __atmp9 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_13_26" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in sigma f
                                                                    __atmp10 in
             __atmp8 + __atmp9)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "sigma" 
  in let _ = for n = min([n]) to max([0;  ((UF max[]  max[]) + 0)]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("f:"); 
     fprintf outch ("f_0#%d,") ((n));  
     (try fprintf outch ("f_r#%d\t") ((f n)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp13 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_10_21" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in sigma sum n in
          assert (__atmp13 >= n)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 