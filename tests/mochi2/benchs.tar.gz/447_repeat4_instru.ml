open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let succ x = let r = let __atmp1 = 1 in x + __atmp1 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "succ" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec repeat f n =
  let r = if n = 0
          then 0
          else
            (let __atmp5 = n - 1 in
             let __atmp4 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_9_25" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in repeat f
                                                                    __atmp5 in
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_7_25" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in f __atmp4)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "repeat" 
  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("f:"); fprintf outch ("f_0#%d,") ((0)); 
  (try fprintf outch ("f_r#%d\t") ((f 0)) with _->(fprintf outch ("	"))); 
  (callflag := true)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp8 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_10_23" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in repeat succ n in
          assert (__atmp8 = n)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 