open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopb i n =
  let r = if i < n
          then
            let __atmp2 = i + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_2_15" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                    __atmp2 n
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopb" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopa k n =
  let r = assert (1 <= k);
          (let __atmp10 = 1 in 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_1_10" in 
             let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                   __atmp10 n);
          (let __atmp9 = 1 in 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_1_10" in 
             let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                   __atmp9 n);
          (let __atmp8 = 1 in 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_1_10" in 
             let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                   __atmp8 n);
          (let __atmp7 = 1 in 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_1_10" in 
             let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                   __atmp7 n);
          (let __atmp6 = 1 in 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_1_10" in 
             let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                   __atmp6 n);
          (let __atmp5 = 1 in 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_1_10" in 
             let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                   __atmp5 n);
          (let __atmp4 = 1 in 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_1_11" in 
             let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                   __atmp4 n)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp13 = 1 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_1_10" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                  __atmp13 n
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp14 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp14
let _ =
  let __atmp15 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp15
let _ = close_out outch 