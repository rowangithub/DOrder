open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let make_array n i =
  let r = (let __atmp2 = 0 <= i in
           let __atmp4 = i < n in assert (__atmp2 && __atmp4));
          0
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "make_array" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let update i n des x =
  let r = let __atmp5 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_31_36" in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in des i in
          let _ = __atmp5 in ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "update" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = for v0 = min([i-1;  n-1]) to max([i+1;  n+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("des:"); 
     fprintf outch ("des_0#%d,") ((v0));  
     (try fprintf outch ("des_r#%d\t") ((des v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec bcopy_aux m src des i =
  let r = if i >= m
          then ()
          else
            ((let __atmp9 = 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_21_28" in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in src i in
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_6_28" in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in update i
                                                                    m des
                                                                    __atmp9);
             (let __atmp7 = i + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_6_31" in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in bcopy_aux
                                                                    m src des
                                                                    __atmp7))
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "bcopy_aux" 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = for v0 = min([m-1]) to max([m+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("src:"); 
     fprintf outch ("src_0#%d,") ((v0));  
     (try fprintf outch ("src_r#%d\t") ((src v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = for v0 = min([m-1]) to max([m+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("des:"); 
     fprintf outch ("des_0#%d,") ((v0));  
     (try fprintf outch ("des_r#%d\t") ((des v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n m =
  let r = let __atmp10 = make_array n in
          let array1 = __atmp10 in
          let __atmp11 = make_array m in
          let array2 = __atmp11 in
          let __atmp13 = n <= m in
          let __atmp14 = n > 0 in
          if __atmp13 && __atmp14
          then
            let __atmp16 = 0 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_22_49" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") (if (__atmp13) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") (if (__atmp14) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in bcopy_aux n
                                                                    array1
                                                                    array2
                                                                    __atmp16
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 