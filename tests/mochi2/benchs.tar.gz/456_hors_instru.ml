open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let c q = let r = () 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "c" 
  in let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let b x q =
  let r = let __atmp1 = 1 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_12_15" in 
            let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp1:%d\t") ((__atmp1)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in x __atmp1
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "b" 
  in let _ = for v0 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("x:"); 
     fprintf outch ("x_0#%d,") ((v0));  
     (try fprintf outch ("x_r#%d\t") ((x v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let a x y q =
  let r = if q = 0
          then
            ((let __atmp5 = 0 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_27_30" in 
                let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in x __atmp5);
             (let __atmp4 = 0 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_32_35" in 
                let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in y __atmp4))
          else assert false
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "a" 
  in let _ = for v0 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("x:"); 
     fprintf outch ("x_0#%d,") ((v0));  
     (try fprintf outch ("x_r#%d\t") ((x v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = for v0 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("y:"); 
     fprintf outch ("y_0#%d,") ((v0));  
     (try fprintf outch ("y_r#%d\t") ((y v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec f n x q =
  let r = if n <= 0
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_33_36" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in x q
          else
            (let __atmp9 = n - 1 in
             let __atmp11 = b x in
             let __atmp8 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_46_61" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in f __atmp9
                                                                    __atmp11 in
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_42_63" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in a x
                                                                    __atmp8 q)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = for v0 = min([n-1]) to max([n+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("x:"); 
     fprintf outch ("x_0#%d,") ((v0));  
     (try fprintf outch ("x_r#%d\t") ((x v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let s n q =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_12_19" in 
    let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
    let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in f n c q 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "s" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp12 = 0 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_13_18" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in s n __atmp12
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 