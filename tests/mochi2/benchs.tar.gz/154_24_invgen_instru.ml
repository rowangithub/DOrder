open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopc i k n =
  let r = if k < n
          then
            (assert (k >= i);
             (let __atmp2 = k + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_20_35" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopc i
                                                                    __atmp2 n))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopc" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopb i j n =
  let r = if j < n
          then
            (
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_3_14" in 
             let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
             let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopc i j n;
             (let __atmp6 = j + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_16_31" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopb i
                                                                    __atmp6 n))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopb" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopa i n =
  let r = if i < n
          then
            (
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_3_14" in 
             let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopb i i n;
             (let __atmp9 = i + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_16_29" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp9 n))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp11 = 0 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_13_22" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                  __atmp11 n
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp12 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "23_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp12
let _ =
  let __atmp13 = (-5) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp13
let _ = close_out outch 