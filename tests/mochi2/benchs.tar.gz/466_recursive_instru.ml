open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec f g x =
  let r = if x >= 0
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_29_32" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in g x
          else
            (let __atmp3 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_40_45" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in f g in
             let __atmp4 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_46_51" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in g x in
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_38_51" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in f __atmp3
                                                                    __atmp4)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = for x = min([0]) to max([x]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("g:"); 
     fprintf outch ("g_0#%d,") ((x));  
     (try fprintf outch ("g_r#%d\t") ((g x)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = for x = min([0]) to max([x]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("g:"); 
     (try fprintf outch ("g_0#%d,") (((g x))) with _->());  
     (try fprintf outch ("g_r#%d\t") ((g (g x))) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let succ x = let r = let __atmp5 = 1 in x + __atmp5 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "succ" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp7 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_21_29" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f succ n in
          assert (__atmp7 >= 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 