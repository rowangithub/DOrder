open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec mult n m =
  let r = let __atmp2 = n <= 0 in
          let __atmp4 = m <= 0 in
          if __atmp2 || __atmp4
          then 0
          else
            (let __atmp7 = m - 1 in
             let __atmp6 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_8_20" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") (if (__atmp2) then 1 else 0) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") (if (__atmp4) then 1 else 0) in 
               let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in mult n
                                                                    __atmp7 in
             n + __atmp6)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "mult" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp10 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_26_34" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in mult n n in
          assert (n <= __atmp10)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 