open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopc i j k n =
  let r = if k < j
          then
            ((let __atmp5 = k - i in
              let __atmp6 = 2 * n in assert (__atmp5 <= __atmp6));
             (let __atmp2 = k + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_2_19" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopc i j
                                                                    __atmp2 n))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopc" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopb i j n =
  let r = let __atmp9 = 3 * i in
          if j < __atmp9
          then
            (
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_3_16" in 
             let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
             let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in loopc i j i
                                                                   n;
             (let __atmp11 = j + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_2_17" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopb i
                                                                    __atmp11
                                                                    n))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopb" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopa i n =
  let r = if i < n
          then
            ((let __atmp16 = 2 * i in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_3_18" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopb i
                                                                    __atmp16
                                                                    n);
             (let __atmp14 = i + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_2_15" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp14
                                                                    n))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp18 = 0 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_1_10" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                  __atmp18 n
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp19 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "25_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp19
let _ =
  let __atmp20 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "26_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp20
let _ =
  let __atmp21 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "27_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp21
let _ =
  let __atmp22 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "28_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp22
let _ = close_out outch 