open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let mk_array n i =
  let r = let __atmp2 = 0 <= i in
          let __atmp4 = i < n in if __atmp2 && __atmp4 then 0 else (-1)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "mk_array" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let update i a x j =
  let r = if j = i
          then x
          else 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_40_44" in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in a j
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "update" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = for j = min([0]) to max([max[i;]]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("a:"); 
     fprintf outch ("a_0#%d,") ((j));  
     (try fprintf outch ("a_r#%d\t") ((a j)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec init i n a =
  let r = if i >= n
          then a
          else
            (let __atmp7 = i + 1 in
             let __atmp9 = update i a 1 in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_7_34" in 
               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in init
                                                                    __atmp7 n
                                                                    __atmp9)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "init" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = for i = min([0]) to max([n]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("a:"); 
     fprintf outch ("a_0#%d,") ((i));  
     (try fprintf outch ("a_r#%d\t") ((a i)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = for i = min([0]) to max([n]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("r:"); 
     fprintf outch ("r_0#%d,") ((i));  
     (try fprintf outch ("r_r#%d\t") ((r i)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n i =
  let r = let __atmp13 = mk_array n in
          let __atmp11 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_10_31" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in init 0 n
                                                                  __atmp13 in
          let x = __atmp11 in
          let __atmp15 = 0 <= i in
          let __atmp17 = i < n in
          if __atmp15 && __atmp17
          then
            let __atmp19 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_12_15" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") (if (__atmp15) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") (if (__atmp17) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("\n") in x i in
            assert (__atmp19 >= 1)
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 