open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopa i k n =
  let r = let __atmp2 = 2 * i in
          let __atmp4 = 2 * n in
          if __atmp2 < __atmp4
          then
            let __atmp6 = i + 2 in
            let __atmp8 = k + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_2_25" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp6
                                                                    __atmp8 n
          else k
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopb j k n =
  let r = let __atmp11 = 2 * j in
          let __atmp13 = 2 * n in
          if __atmp11 < __atmp13
          then
            let __atmp17 = assert (k > 0) in
            let _ = __atmp17 in
            let __atmp18 = j + 2 in
            let __atmp20 = k - 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_2_23" in 
              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                    __atmp18
                                                                    __atmp20
                                                                    n
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopb" 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp22 = 0 in
          let i = __atmp22 in
          let __atmp23 = 0 in
          let k = __atmp23 in
          if n >= 0
          then
            let __atmp26 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_9_20" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopa i k n in
            let k = __atmp26 in
            let __atmp27 = 0 in
            let j = __atmp27 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_2_13" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopb j k n
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp28 = 10 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "23_8_15" in 
    let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp28
let _ =
  let __atmp29 = 15 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_8_15" in 
    let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp29
let _ =
  let __atmp30 = 7 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "25_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") ((__atmp30)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp30
let _ =
  let __atmp31 = (-5) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "26_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp31:%d\t") ((__atmp31)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp31
let _ = close_out outch 