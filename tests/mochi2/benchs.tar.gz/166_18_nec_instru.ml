open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop flag b j =
  let r = if b < 100
          then
            let __atmp6 =
              if flag > 0 then let __atmp5 = 1 in j + __atmp5 else j in
            let j = __atmp6 in
            let __atmp7 = b + 1 in
            let b = __atmp7 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_3_16" in 
              let _ = if (!callflag) then fprintf outch ("flag:%d\t") ((flag)) in 
              let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) in 
              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
              let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop flag b
                                                                    j
          else j
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("flag:%d\t") ((flag)) 
  in let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main flag =
  let r = let __atmp9 = 0 in
          let j = __atmp9 in
          let __atmp10 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_11_24" in 
            let _ = if (!callflag) then fprintf outch ("flag:%d\t") ((flag)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
            let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loop flag 0 j in
          let res = __atmp10 in if flag > 0 then assert (res = 100) else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("flag:%d\t") ((flag)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp16 = 101 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp16
let _ =
  let __atmp17 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp17
let _ =
  let __atmp18 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "22_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp18
let _ =
  let __atmp19 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "23_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp19
let _ = close_out outch 