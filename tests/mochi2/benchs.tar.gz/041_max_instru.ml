open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let max1 (x : int) (y : int) (z : int) max2 =
  let r = let __atmp1 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_6_16" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in max2 x y in
           let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_1_18" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp1:%d\t") ((__atmp1)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in max2 __atmp1
                                                                  z
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "max1" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) 
  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("max2:"); (try fprintf outch ("max2_0#%d,") (((max2 x  y))) with _->()); 
  fprintf outch ("max2_1#%d,") ((z)); 
  (try fprintf outch ("max2_r#%d\t") ((max2 (max2 x  y) z)) with _->(fprintf outch ("	"))); 
  (callflag := true))  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("max2:"); fprintf outch ("max2_0#%d,") ((x)); fprintf outch ("max2_1#%d,") ((y)); 
  (try fprintf outch ("max2_r#%d\t") ((max2 x y)) with _->(fprintf outch ("	"))); 
  (callflag := true)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let f x y = let r = (if x >= y then x else y : int ) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main (x : int) y z =
  let r = let __atmp2 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_10_22" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in max1 x y z f in
          let m = __atmp2 in
          let __atmp4 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_10_15" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f x m in
          assert (__atmp4 = m)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp5 = 1 in
  let __atmp6 = 2 in
  let __atmp7 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_8_18" in 
    let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp5 __atmp6
                                                          __atmp7
let _ = close_out outch 