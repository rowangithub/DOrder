open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let apply (b : int) (f : int -> unit) x =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_37_40" in 
    let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) in 
    let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in f x 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "apply" 
  in let _ = if (!callflag) then fprintf outch ("b:%d\t") ((b)) 
  in let _ = for v0 = min([b-1]) to max([b+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("f:"); 
     fprintf outch ("f_0#%d,") ((v0));  
     (try fprintf outch ("f_r#%d\t") ((f v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let check (x : int) (y : int) = let r = assert (x = y) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "check" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main (n : int) =
  let r = let __atmp2 = check n in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_19_38" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in apply n
                                                                  __atmp2 n
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp3 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp3
let _ = close_out outch 