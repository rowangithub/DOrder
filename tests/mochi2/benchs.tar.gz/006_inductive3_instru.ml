open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec f x =
  let r = if x < (-1)
          then
            let __atmp8 = (-2) in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_4_10" in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in f __atmp8
          else
            if x <= 1
            then
              (let __atmp5 = 2 * x in let __atmp7 = 1 in __atmp5 - __atmp7)
            else x
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp10 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_9_12" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f 3 in
          assert (__atmp10 >= 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp13 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp13

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (10)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (15)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (15)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (10)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (15)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (17)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (12)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (10)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (5)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (15)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (12)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (10)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (3)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (12)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (3)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (3)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (3)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (10)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (17)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (3)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (3)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (17)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (3)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (15)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (15)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (17)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (3)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (17)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (12)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (10)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (10)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (15)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (12)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (17)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (12)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (5)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (10)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (15)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (17)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (12)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (5)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (5)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (17)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (17)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (5)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (10)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (2)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (5)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (5)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)
let _ = close_out outch