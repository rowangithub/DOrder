open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let max max2 (x : int) (y : int) (z : int) =
  let r = (
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_45_62" in 
    let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
    let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
    let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in max2 (
                                                          let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_50_60" in 
                                                          let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                                                          let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                                                          let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) in 
                                                          let _ = if (!callflag) then fprintf outch ("\n") in 
                                                          max2 x y) z : 
    int ) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "max" 
  in let _ = for dummy = min([]) to max([]) doin let _ = for z = min([z]) to max([z]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("max2:"); 
     fprintf outch ("max2_0#%d,") ((dummy)); fprintf outch ("max2_1#%d,") ((z));  
     (try fprintf outch ("max2_r#%d\t") ((max2 dummy z)) with _->(fprintf outch ("	"))); 
     (callflag := true);) donedone
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let f x y = let r = (if x >= y then x else y : int ) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main (x : int) y z =
  let r = let __atmp1 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_10_21" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in max f x y z in
          let m = __atmp1 in
          let __atmp3 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_10_15" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp1:%d\t") ((__atmp1)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f x m in
          assert (__atmp3 = m)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 