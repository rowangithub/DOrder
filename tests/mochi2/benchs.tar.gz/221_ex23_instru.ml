open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop (y : int) z c =
  let r = if c < 36
          then
            ((let __atmp8 = 0 <= z in
              let __atmp10 = z < 4608 in assert (__atmp8 && __atmp10));
             (let __atmp3 = z + 1 in
              let __atmp5 = c + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_2_20" in 
                let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) in 
                let _ = if (!callflag) then fprintf outch ("c:%d\t") ((c)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loop y
                                                                    __atmp3
                                                                    __atmp5))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) 
  in let _ = if (!callflag) then fprintf outch ("c:%d\t") ((c)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main y =
  let r = let __atmp12 = 0 in
          let c = __atmp12 in
          let __atmp14 = y >= 0 in
          let __atmp16 = y <= 127 in
          if __atmp14 && __atmp16
          then
            let __atmp18 = y * 36 in
            let z = __atmp18 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_2_12" in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
              let _ = if (!callflag) then fprintf outch ("c:%d\t") ((c)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") (if (__atmp14) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") (if (__atmp16) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
              let _ = if (!callflag) then fprintf outch ("z:%d\t") ((z)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop y z c
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp20 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp20
let _ =
  let __atmp21 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp21
let _ =
  let __atmp22 = 127 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp22
let _ =
  let __atmp23 = 128 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp23
let _ = close_out outch 