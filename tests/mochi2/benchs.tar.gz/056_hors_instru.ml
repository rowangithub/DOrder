open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let c (q : int) = let r = () 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "c" 
  in let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let b x (q : int) =
  let r = (
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_25_28" in 
    let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in x 1 : unit ) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "b" 
  in let _ = for v0 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("x:"); 
     fprintf outch ("x_0#%d,") ((v0));  
     (try fprintf outch ("x_r#%d\t") ((x v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let a (x : int -> unit) (y : int -> unit) q =
  let r = assert (q = 0);
          (let __atmp2 = 0 in 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_55_58" in 
             let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in x __atmp2);
          (let __atmp1 = 0 in 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_60_63" in 
             let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp1:%d\t") ((__atmp1)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in y __atmp1)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "a" 
  in let _ = for v0 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("x:"); 
     fprintf outch ("x_0#%d,") ((v0));  
     (try fprintf outch ("x_r#%d\t") ((x v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = for v0 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("y:"); 
     fprintf outch ("y_0#%d,") ((v0));  
     (try fprintf outch ("y_r#%d\t") ((y v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec f n x q =
  let r = if n <= 0
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_33_36" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in x q
          else
            (let __atmp8 = n - 1 in
             let __atmp10 = b x in
             let __atmp7 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_46_61" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in f __atmp8
                                                                    __atmp10 in
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_42_63" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in a x
                                                                    __atmp7 q)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = for v0 = min([n-1]) to max([n+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("x:"); 
     fprintf outch ("x_0#%d,") ((v0));  
     (try fprintf outch ("x_r#%d\t") ((x v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let s n q =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_12_19" in 
    let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
    let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in f n c q 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "s" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp11 = 0 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_13_18" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in s n __atmp11
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp12 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp12
let _ = close_out outch 