open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let f x y =
  let r = let __atmp3 = x > 0 in
          let __atmp5 = y <= 0 in
          let __atmp2 = __atmp3 && __atmp5 in assert (not __atmp2)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let g x =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_10_15" in 
    let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in f x x 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "g" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 