open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopa i k n =
  let r = if i < n
          then
            let __atmp2 = i + 1 in
            let __atmp4 = k + 2 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_2_21" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp2
                                                                    __atmp4 n
          else k
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopb j k n =
  let r = if j < n
          then
            let __atmp9 = assert (k > 0) in
            let _ = __atmp9 in
            let __atmp10 = j + 2 in
            let __atmp12 = k - 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_4_23" in 
              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                    __atmp10
                                                                    __atmp12
                                                                    n
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopb" 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp14 = 0 in
          let i = __atmp14 in
          let __atmp15 = 0 in
          let k = __atmp15 in
          let __atmp16 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_10_21" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopa i k n in
          let k = __atmp16 in
          let __atmp17 = 0 in
          let j = __atmp17 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_1_12" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
            let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopb j k n
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp18 = 10 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_8_15" in 
    let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp18
let _ =
  let __atmp19 = 9 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "22_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp19
let _ =
  let __atmp20 = (-5) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "23_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp20

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (10)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)
let _ = close_out outch