open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec copy x =
  let r = if x = 0
          then x
          else
            (let __atmp3 = 1 in
             let __atmp5 = x - 1 in
             let __atmp4 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_40_50" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in copy
                                                                    __atmp5 in
             __atmp3 + __atmp4)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "copy" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp9 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_26_34" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in copy n in
          let __atmp8 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_21_34" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in copy __atmp9 in
          assert (__atmp8 = n)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp10 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp10
let _ = close_out outch 