open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopa i0 k n0 =
  let r = if i0 < n0
          then
            let __atmp2 = i0 + 1 in
            let __atmp4 = k + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_2_23" in 
              let _ = if (!callflag) then fprintf outch ("i0:%d\t") ((i0)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp2
                                                                    __atmp4
                                                                    n0
          else k
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("i0:%d\t") ((i0)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopb i1 k n1 =
  let r = if i1 < n1
          then
            let __atmp7 = i1 + 1 in
            let __atmp9 = k + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_2_23" in 
              let _ = if (!callflag) then fprintf outch ("i1:%d\t") ((i1)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                    __atmp7
                                                                    __atmp9
                                                                    n1
          else k
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopb" 
  in let _ = if (!callflag) then fprintf outch ("i1:%d\t") ((i1)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopc j1 k n1 =
  let r = if j1 < n1
          then
            let __atmp14 = assert (k > 0) in
            let _ = __atmp14 in
            let __atmp15 = j1 + 1 in
            let __atmp17 = k - 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_2_23" in 
              let _ = if (!callflag) then fprintf outch ("j1:%d\t") ((j1)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopc
                                                                    __atmp15
                                                                    __atmp17
                                                                    n1
          else k
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopc" 
  in let _ = if (!callflag) then fprintf outch ("j1:%d\t") ((j1)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopd j0 k n0 =
  let r = if j0 < n0
          then
            let __atmp22 = assert (k > 0) in
            let _ = __atmp22 in
            let __atmp23 = j0 + 1 in
            let __atmp25 = k - 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_2_23" in 
              let _ = if (!callflag) then fprintf outch ("j0:%d\t") ((j0)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopd
                                                                    __atmp23
                                                                    __atmp25
                                                                    n0
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopd" 
  in let _ = if (!callflag) then fprintf outch ("j0:%d\t") ((j0)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n0 n1 =
  let r = let __atmp27 = 0 in
          let i0 = __atmp27 in
          let __atmp28 = 0 in
          let k = __atmp28 in
          let __atmp29 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "27_9_22" in 
            let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) in 
            let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
            let _ = if (!callflag) then fprintf outch ("i0:%d\t") ((i0)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopa i0 k n0 in
          let k = __atmp29 in
          let __atmp30 = 0 in
          let i1 = __atmp30 in
          let __atmp31 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "30_9_22" in 
            let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) in 
            let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
            let _ = if (!callflag) then fprintf outch ("i0:%d\t") ((i0)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") ((__atmp30)) in 
            let _ = if (!callflag) then fprintf outch ("i1:%d\t") ((i1)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopb i1 k n1 in
          let k = __atmp31 in
          let __atmp32 = 0 in
          let j1 = __atmp32 in
          let __atmp33 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "33_9_22" in 
            let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) in 
            let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
            let _ = if (!callflag) then fprintf outch ("i0:%d\t") ((i0)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") ((__atmp30)) in 
            let _ = if (!callflag) then fprintf outch ("i1:%d\t") ((i1)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp31:%d\t") ((__atmp31)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp32:%d\t") ((__atmp32)) in 
            let _ = if (!callflag) then fprintf outch ("j1:%d\t") ((j1)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopc j1 k n1 in
          let k = __atmp33 in
          let __atmp34 = 0 in
          let j0 = __atmp34 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "37_2_15" in 
            let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) in 
            let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
            let _ = if (!callflag) then fprintf outch ("i0:%d\t") ((i0)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") ((__atmp30)) in 
            let _ = if (!callflag) then fprintf outch ("i1:%d\t") ((i1)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp31:%d\t") ((__atmp31)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp32:%d\t") ((__atmp32)) in 
            let _ = if (!callflag) then fprintf outch ("j1:%d\t") ((j1)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp33:%d\t") ((__atmp33)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp34:%d\t") ((__atmp34)) in 
            let _ = if (!callflag) then fprintf outch ("j0:%d\t") ((j0)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopd j0 k n0
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) 
  in let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp35 = 2 in
  let __atmp36 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "40_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp35:%d\t") ((__atmp35)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp36:%d\t") ((__atmp36)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp35
                                                          __atmp36
let _ =
  let __atmp37 = 3 in
  let __atmp38 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "41_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp37:%d\t") ((__atmp37)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp38:%d\t") ((__atmp38)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp37
                                                          __atmp38
let _ =
  let __atmp39 = (-1) in
  let __atmp40 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "42_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp39:%d\t") ((__atmp39)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp40:%d\t") ((__atmp40)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp39
                                                          __atmp40
let _ =
  let __atmp41 = (-2) in
  let __atmp42 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "43_8_19" in 
    let _ = if (!callflag) then fprintf outch ("__atmp41:%d\t") ((__atmp41)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp42:%d\t") ((__atmp42)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp41
                                                          __atmp42
let _ =
  let __atmp43 = 2 in
  let __atmp44 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "44_8_19" in 
    let _ = if (!callflag) then fprintf outch ("__atmp43:%d\t") ((__atmp43)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp44:%d\t") ((__atmp44)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp43
                                                          __atmp44
let _ = close_out outch 