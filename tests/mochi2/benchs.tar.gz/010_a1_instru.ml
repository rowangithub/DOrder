open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let f x = let r = let __atmp1 = 2 in x + __atmp1 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let g (i : int) (h : int -> int) =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_29_32" in 
    let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in h i 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "g" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then ((callflag := false); 
  fprintf outch ("h:"); fprintf outch ("h_0#%d,") ((i)); 
  (try fprintf outch ("h_r#%d\t") ((h i)) with _->(fprintf outch ("	"))); 
  (callflag := true)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main y =
  let r = let t = y in
          let __atmp2 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_9_14" in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("t:%d\t") ((t)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in g y f in
          let z = __atmp2 in assert (z > t)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp4 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp4
let _ =
  let __atmp5 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp5
let _ =
  let __atmp6 = 10 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_8_15" in 
    let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp6
let _ = close_out outch 