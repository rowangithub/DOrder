open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop i n sum =
  let r = if i < n
          then
            let __atmp4 = 1 + i in
            let __atmp6 = sum + i in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_2_24" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp4 n
                                                                    __atmp6
          else assert (sum >= 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp7 = 0 in
          let sum = __atmp7 in
          if n >= 0
          then
            let __atmp10 = 0 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_2_14" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
              let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp10
                                                                    n sum
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp11 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp11
let _ =
  let __atmp12 = (-5) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp12
let _ = close_out outch 