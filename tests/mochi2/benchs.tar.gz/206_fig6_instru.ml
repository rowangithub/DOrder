open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop y =
  let r = if y > 0
          then
            let __atmp4 = y - 1 in
            let y = __atmp4 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_2_8" in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop y
          else if false then assert false else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main y =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_1_7" in 
    let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in loop y 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp6 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp6
let _ =
  let __atmp7 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp7
let _ = close_out outch 