open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec cps_sum n k =
  let r = (if n <= 0
           then 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_4_7" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in k 0
           else
             (let f x =
                let r = 
                  let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_14_23" in 
                  let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                  let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                  let _ = if (!callflag) then fprintf outch ("\n") in 
                  k (x + n) 
                in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
                in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
                in let _ = if (!callflag) then fprintf outch ("\n") in r in
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_4_19" in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in cps_sum
                                                                    (n - 1) f) : 
    unit ) 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "cps_sum" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = for v0 = min([n-1]) to max([n+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("k:"); 
     fprintf outch ("k_0#%d,") ((v0));  
     (try fprintf outch ("k_r#%d\t") ((k v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp2 x = let r = assert (x >= n) 
            in let _ = if (!callflag) then fprintf outch ("name:%s\t") "__atmp2" 
            in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
            in let _ = if (!callflag) then fprintf outch ("\n") in r in
          let f = __atmp2 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_2_13" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in cps_sum n f
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 