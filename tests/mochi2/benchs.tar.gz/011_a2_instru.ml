open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec f g x =
  let r = if x >= 0
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_16_19" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in g x
          else
            (let __atmp3 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_10_13" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in f g in
             let p = __atmp3 in
             let __atmp4 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_10_13" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in g x in
             let q = __atmp4 in
             let __atmp5 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_10_15" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
               let _ = if (!callflag) then fprintf outch ("q:%d\t") ((q)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in f p q in
             let s = __atmp5 in s)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = for x = min([0]) to max([x]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("g:"); 
     fprintf outch ("g_0#%d,") ((x));  
     (try fprintf outch ("g_r#%d\t") ((g x)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = for x = min([0]) to max([x]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("g:"); 
     (try fprintf outch ("g_0#%d,") (((g x))) with _->());  
     (try fprintf outch ("g_r#%d\t") ((g (g x))) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let succ x = let r = let __atmp6 = 1 in x + __atmp6 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "succ" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp7 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_9_17" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f succ n in
          let r = __atmp7 in assert (r >= 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp10 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp10
let _ =
  let __atmp11 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp11
let _ = close_out outch 