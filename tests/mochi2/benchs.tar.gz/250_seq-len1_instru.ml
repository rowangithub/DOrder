open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopa i k n =
  let r = if i < n
          then
            let __atmp2 = i + 1 in
            let __atmp4 = k + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_15_34" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp2
                                                                    __atmp4 n
          else k
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopb i k n =
  let r = if i < n
          then
            let __atmp7 = i + 1 in
            let __atmp9 = k - 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_15_34" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopb
                                                                    __atmp7
                                                                    __atmp9 n
          else k
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopb" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopc i k n =
  let r = if i < n
          then
            (assert (k > 0);
             (let __atmp12 = i + 1 in
              let __atmp14 = k - 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_32_51" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopc
                                                                    __atmp12
                                                                    __atmp14
                                                                    n))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopc" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n0 n1 n2 =
  let r = let __atmp19 = n0 >= 0 in
          let __atmp22 = n1 >= 0 in
          let __atmp24 = n2 >= 0 in
          let __atmp21 = __atmp22 && __atmp24 in
          if __atmp19 && __atmp21
          then
            let __atmp26 = 0 in
            let i = __atmp26 in
            let __atmp27 = 0 in
            let k = __atmp27 in
            let __atmp28 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_10_22" in 
              let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) in 
              let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
              let _ = if (!callflag) then fprintf outch ("n2:%d\t") ((n2)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") (if (__atmp19) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") (if (__atmp22) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") (if (__atmp24) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") (if (__atmp21) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopa i k
                                                                    n0 in
            let k = __atmp28 in
            let __atmp29 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_10_22" in 
              let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) in 
              let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
              let _ = if (!callflag) then fprintf outch ("n2:%d\t") ((n2)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") (if (__atmp19) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") (if (__atmp22) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") (if (__atmp24) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") (if (__atmp21) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopa i k
                                                                    n1 in
            let k = __atmp29 in
            let __atmp30 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_11_23" in 
              let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) in 
              let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
              let _ = if (!callflag) then fprintf outch ("n2:%d\t") ((n2)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") (if (__atmp19) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") (if (__atmp22) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") (if (__atmp24) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") (if (__atmp21) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopa i k
                                                                    n2 in
            let k = __atmp30 in
            let __atmp31 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_10_22" in 
              let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) in 
              let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
              let _ = if (!callflag) then fprintf outch ("n2:%d\t") ((n2)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") (if (__atmp19) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") (if (__atmp22) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") (if (__atmp24) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") (if (__atmp21) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") ((__atmp30)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopb i k
                                                                    n2 in
            let k = __atmp31 in
            let __atmp32 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "22_11_23" in 
              let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) in 
              let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
              let _ = if (!callflag) then fprintf outch ("n2:%d\t") ((n2)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") (if (__atmp19) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") (if (__atmp22) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") (if (__atmp24) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") (if (__atmp21) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") ((__atmp30)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp31:%d\t") ((__atmp31)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopb i k
                                                                    n1 in
            let k = __atmp32 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "23_2_14" in 
              let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) in 
              let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
              let _ = if (!callflag) then fprintf outch ("n2:%d\t") ((n2)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") (if (__atmp19) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") (if (__atmp22) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") (if (__atmp24) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") (if (__atmp21) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp30:%d\t") ((__atmp30)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp31:%d\t") ((__atmp31)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp32:%d\t") ((__atmp32)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopc i k
                                                                    n0
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n0:%d\t") ((n0)) 
  in let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) 
  in let _ = if (!callflag) then fprintf outch ("n2:%d\t") ((n2)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp33 = 2 in
  let __atmp34 = 3 in
  let __atmp35 = 4 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "26_8_18" in 
    let _ = if (!callflag) then fprintf outch ("__atmp33:%d\t") ((__atmp33)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp34:%d\t") ((__atmp34)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp35:%d\t") ((__atmp35)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp33
                                                          __atmp34 __atmp35
let _ =
  let __atmp36 = 3 in
  let __atmp37 = 2 in
  let __atmp38 = 4 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "27_8_18" in 
    let _ = if (!callflag) then fprintf outch ("__atmp36:%d\t") ((__atmp36)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp37:%d\t") ((__atmp37)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp38:%d\t") ((__atmp38)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp36
                                                          __atmp37 __atmp38
let _ =
  let __atmp39 = (-2) in
  let __atmp40 = (-3) in
  let __atmp41 = (-4) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "28_8_27" in 
    let _ = if (!callflag) then fprintf outch ("__atmp39:%d\t") ((__atmp39)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp40:%d\t") ((__atmp40)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp41:%d\t") ((__atmp41)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp39
                                                          __atmp40 __atmp41
let _ = close_out outch 