open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop i j p =
  let r = if i < 100
          then
            (if i > p
             then
               let __atmp6 = i + 1 in
               let __atmp8 = 1 in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_18_32" in 
                 let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                 let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                 let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 loop __atmp6 __atmp8 p
             else
               (let __atmp4 = i + 1 in 
                  let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_7_21" in 
                  let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                  let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                  let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) in 
                  let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
                  let _ = if (!callflag) then fprintf outch ("\n") in 
                  loop __atmp4 j p))
          else j
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main p =
  let r = let __atmp9 = 0 in
          let i = __atmp9 in
          let __atmp10 = 0 in
          let j = __atmp10 in
          let __atmp12 = p >= 25 in
          let __atmp14 = p < 75 in
          if __atmp12 && __atmp14
          then
            let __atmp16 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_12_22" in 
              let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") (if (__atmp12) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") (if (__atmp14) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop i j p in
            let res = __atmp16 in assert (res = 1)
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp19 = 102 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_8_18" in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp19
let _ =
  let __atmp20 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp20

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (125)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (39)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)
let _ = close_out outch