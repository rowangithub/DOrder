open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec sum n =
  let r = if n <= 0
          then 0
          else
            (let __atmp4 = n - 1 in
             let __atmp3 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_8_17" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in sum
                                                                    __atmp4 in
             n + __atmp3)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "sum" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp8 = 3 * n in
          let __atmp7 = __atmp8 - 3 in
          let __atmp11 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_30_35" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in sum n in
          assert (__atmp7 <= __atmp11)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 