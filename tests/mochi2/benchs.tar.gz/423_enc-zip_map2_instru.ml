open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_17_23" in 
    let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in loop x 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec zip x y =
  let r = if x = 0
          then (if y = 0 then x else assert false)
          else
            if y = 0
            then assert false
            else
              (let __atmp5 = 1 in
               let __atmp7 = x - 1 in
               let __atmp9 = y - 1 in
               let __atmp6 = 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_10_25" in 
                 let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                 let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 zip __atmp7 __atmp9 in
               __atmp5 + __atmp6)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "zip" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec map x =
  let r = if x = 0
          then x
          else
            (let __atmp15 = 1 in
             let __atmp17 = x - 1 in
             let __atmp16 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_24_33" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in map
                                                                    __atmp17 in
             __atmp15 + __atmp16)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "map" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp21 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_13_22" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in zip n n in
          let __atmp20 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_9_22" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in map __atmp21 in
          assert (__atmp20 = n)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 