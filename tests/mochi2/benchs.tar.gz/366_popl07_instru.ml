open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x y (m : int) (n : int) =
  let r = if x < m
          then
            (if x < n
             then
               let __atmp7 = x + 1 in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_3_19" in 
                 let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                 let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                 let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                 let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 loop __atmp7 y m n
             else
               (let __atmp3 = x + 1 in
                let __atmp5 = y + 1 in 
                  let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_7_27" in 
                  let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                  let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                  let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                  let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                  let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
                  let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                  let _ = if (!callflag) then fprintf outch ("\n") in 
                  loop __atmp3 __atmp5 m n))
          else y
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main m =
  let r = let __atmp9 = 0 in
          let x = __atmp9 in
          let __atmp10 = 3 in
          let y = __atmp10 in
          let __atmp12 = m > y in
          let __atmp13 = y > 0 in
          if __atmp12 && __atmp13
          then
            let __atmp15 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_12_24" in 
              let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") (if (__atmp12) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") (if (__atmp13) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop x y m
                                                                    y in
            let res = __atmp15 in assert (res = m)
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp17 = 10 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_8_15" in 
    let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp17
let _ =
  let __atmp18 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp18
let _ =
  let __atmp19 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "22_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp19
let _ = close_out outch 