open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop i (j : int) k p n =
  let r = if i < n
          then
            (if i >= p
             then
               let __atmp5 = i + 1 in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_20_38" in 
                 let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                 let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                 let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
                 let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) in 
                 let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 loop __atmp5 k k p n
             else
               (let __atmp3 = i + 1 in 
                  let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_7_25" in 
                  let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                  let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                  let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
                  let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) in 
                  let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                  let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
                  let _ = if (!callflag) then fprintf outch ("\n") in 
                  loop __atmp3 j k p n))
          else j
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main p n =
  let r = let __atmp7 = 0 in
          let i = __atmp7 in
          let __atmp8 = 0 in
          let j = __atmp8 in
          let __atmp9 = 3 in
          let k = __atmp9 in
          let __atmp10 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_12_26" in 
            let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
            let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loop i j k p
                                                                  n in
          let res = __atmp10 in
          let __atmp12 = p > 0 in
          let __atmp14 = n > p in
          if __atmp12 && __atmp14 then assert (res = k) else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("p:%d\t") ((p)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp16 = (-1) in
  let __atmp17 = (-3) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp16
                                                          __atmp17

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (15)  (12)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (11)  (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (9)  (-3)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (3)  (-4)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)  (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (10)  (10)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)  (12)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)  (-7)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)  (-3)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)  (-2)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (19)  (10)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (14)  (13)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (6)  (8)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (8)  (1)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)  (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (16)  (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)  (12)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-2)  (-3)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (0)  (5)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)  (0)

let _ = fprintf outch "env:newtest\t\n"
let _ = main   (18)  (14)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (12)  (16)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-8)  (3)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)  (-5)
let _ = fprintf outch "env:newtest\t\n"
let _ = main   (-1)  (-1)
let _ = close_out outch