open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec f g x =
  let r = if x < (-3)
          then
            let __atmp8 = (-4) in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_4_12" in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in f g __atmp8
          else
            if x <= 1
            then 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_4_7" in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in g x
            else
              (let __atmp5 = 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_6_11" in 
                 let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 f g in
               let __atmp6 = x - 2 in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_4_19" in 
                 let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 f __atmp5 __atmp6)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = for x = min([x]) to max([(0 - 3);  1]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("g:"); 
     fprintf outch ("g_0#%d,") ((x));  
     (try fprintf outch ("g_r#%d\t") ((g x)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let incr x = let r = let __atmp9 = 1 in x + __atmp9 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "incr" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp11 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_9_17" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f incr 3 in
          assert (__atmp11 >= (-3))
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp14 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp14
let _ = close_out outch 