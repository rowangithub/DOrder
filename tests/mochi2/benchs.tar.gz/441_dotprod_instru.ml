open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let make_array n = let r = n 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "make_array" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let arraysize src = let r = src 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "arraysize" 
  in let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let update des i x =
  let r = let __atmp2 = 0 <= i in
          let __atmp4 = i < des in assert (__atmp2 && __atmp4)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "update" 
  in let _ = if (!callflag) then fprintf outch ("des:%d\t") ((des)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let sub src i =
  let r = (let __atmp6 = 0 <= i in
           let __atmp8 = i < src in assert (__atmp6 && __atmp8));
          0
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "sub" 
  in let _ = if (!callflag) then fprintf outch ("src:%d\t") ((src)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec dotprod_aux n v1 v2 i sum =
  let r = if i = n
          then sum
          else
            (let __atmp10 = i + 1 in
             let __atmp14 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_40_50" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("v1:%d\t") ((v1)) in 
               let _ = if (!callflag) then fprintf outch ("v2:%d\t") ((v2)) in 
               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
               let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in sub v1 i in
             let __atmp15 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_53_63" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("v1:%d\t") ((v1)) in 
               let _ = if (!callflag) then fprintf outch ("v2:%d\t") ((v2)) in 
               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
               let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in sub v2 i in
             let __atmp13 = __atmp14 * __atmp15 in
             let __atmp12 = sum + __atmp13 in 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_7_64" in 
               let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
               let _ = if (!callflag) then fprintf outch ("v1:%d\t") ((v1)) in 
               let _ = if (!callflag) then fprintf outch ("v2:%d\t") ((v2)) in 
               let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
               let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in dotprod_aux
                                                                    n v1 v2
                                                                    __atmp10
                                                                    __atmp12)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "dotprod_aux" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("v1:%d\t") ((v1)) 
  in let _ = if (!callflag) then fprintf outch ("v2:%d\t") ((v2)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let dotprod v1 v2 =
  let r = let __atmp16 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_32_46" in 
            let _ = if (!callflag) then fprintf outch ("v1:%d\t") ((v1)) in 
            let _ = if (!callflag) then fprintf outch ("v2:%d\t") ((v2)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in arraysize v1 in
          let __atmp17 = 0 in
          let __atmp18 = 0 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_20_56" in 
            let _ = if (!callflag) then fprintf outch ("v1:%d\t") ((v1)) in 
            let _ = if (!callflag) then fprintf outch ("v2:%d\t") ((v2)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in dotprod_aux
                                                                  __atmp16 v1
                                                                  v2 __atmp17
                                                                  __atmp18
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "dotprod" 
  in let _ = if (!callflag) then fprintf outch ("v1:%d\t") ((v1)) 
  in let _ = if (!callflag) then fprintf outch ("v2:%d\t") ((v2)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n m =
  let r = let __atmp19 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_11_23" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in make_array n in
          let v1 = __atmp19 in
          let __atmp20 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_11_23" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
            let _ = if (!callflag) then fprintf outch ("v1:%d\t") ((v1)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in make_array m in
          let v2 = __atmp20 in
          let __atmp22 = 0 <= n in
          let __atmp24 = n = m in
          if __atmp22 && __atmp24
          then
            (
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_23_36" in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
             let _ = if (!callflag) then fprintf outch ("v1:%d\t") ((v1)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
             let _ = if (!callflag) then fprintf outch ("v2:%d\t") ((v2)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") (if (__atmp22) then 1 else 0) in 
             let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") (if (__atmp24) then 1 else 0) in 
             let _ = if (!callflag) then fprintf outch ("\n") in dotprod v1
                                                                   v2;
             ())
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 