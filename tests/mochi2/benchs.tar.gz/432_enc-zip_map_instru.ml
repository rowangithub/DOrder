open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x =
  let r = 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "1_17_23" in 
    let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in loop x 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec zip x y =
  let r = if x = 0
          then
            (if y = 0
             then 0
             else
               (let __atmp14 = () in 
                  let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_10_16" in 
                  let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                  let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                  let _ = if (!callflag) then fprintf outch ("\n") in 
                  loop __atmp14))
          else
            if y = 0
            then
              (let __atmp11 = () in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "6_18_24" in 
                 let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                 let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 loop __atmp11)
            else
              (let __atmp5 = 1 in
               let __atmp7 = x - 1 in
               let __atmp9 = y - 1 in
               let __atmp6 = 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_12_27" in 
                 let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                 let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 zip __atmp7 __atmp9 in
               __atmp5 + __atmp6)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "zip" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec map x =
  let r = if x = 0
          then 0
          else
            (let __atmp17 = 1 in
             let __atmp19 = x - 1 in
             let __atmp18 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_24_33" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in map
                                                                    __atmp19 in
             __atmp17 + __atmp18)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "map" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp23 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_12_21" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in zip n n in
          let __atmp22 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_8_21" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in map __atmp23 in
          assert (__atmp22 >= n)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 