open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x y m n =
  let r = if x < n
          then
            let __atmp3 = x + 1 in
            let x = __atmp3 in
            let __atmp7 = if x > m then let __atmp6 = 1 in y + __atmp6 else y in
            let y = __atmp7 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_2_14" in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop x y m
                                                                    n
          else assert (y = n)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n m =
  let r = let __atmp9 = n >= 0 in
          let __atmp12 = m >= 0 in
          let __atmp14 = n > m in
          let __atmp11 = __atmp12 && __atmp14 in
          if __atmp9 && __atmp11
          then
            let __atmp15 = 0 in
            let x = __atmp15 in
            let y = m in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_2_14" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") (if (__atmp9) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") (if (__atmp12) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") (if (__atmp14) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") (if (__atmp11) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop x y m
                                                                    n
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp16 = 5 in
  let __atmp17 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp16
                                                          __atmp17
let _ =
  let __atmp18 = 6 in
  let __atmp19 = 4 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp18
                                                          __atmp19
let _ =
  let __atmp20 = (-2) in
  let __atmp21 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp20
                                                          __atmp21
let _ = close_out outch 