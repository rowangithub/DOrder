open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x y =
  let r = if x < 0
          then
            let __atmp3 = x + y in
            let __atmp4 = y + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_2_18" in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp3
                                                                    __atmp4
          else y
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main y =
  let r = let __atmp6 = (-50) in
          let x = __atmp6 in
          let __atmp7 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_14_22" in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loop x y in
          let result = __atmp7 in assert (result > 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp10 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp10
let _ =
  let __atmp11 = (-100) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_8_19" in 
    let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") ((__atmp11)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp11
let _ = close_out outch 