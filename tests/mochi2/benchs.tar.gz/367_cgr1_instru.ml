open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x y =
  let r = if x < 100
          then
            let __atmp8 = x + 2 in
            let __atmp10 = y + 2 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_2_18" in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp8
                                                                    __atmp10
          else
            (let __atmp4 = x <> 4 in
             let __atmp6 = y <> 0 in assert (__atmp4 || __atmp6))
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main x y =
  let r = let __atmp13 = 0 <= x in
          let __atmp16 = x <= 2 in
          let __atmp19 = 0 <= y in
          let __atmp21 = y <= 2 in
          let __atmp18 = __atmp19 && __atmp21 in
          let __atmp15 = __atmp16 && __atmp18 in
          if __atmp13 && __atmp15
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_2_10" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") (if (__atmp13) then 1 else 0) in 
            let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") (if (__atmp16) then 1 else 0) in 
            let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") (if (__atmp19) then 1 else 0) in 
            let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") (if (__atmp21) then 1 else 0) in 
            let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") (if (__atmp18) then 1 else 0) in 
            let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") (if (__atmp15) then 1 else 0) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loop x y
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp23 = (-1) in
  let __atmp24 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") ((__atmp24)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp23
                                                          __atmp24
let _ = close_out outch 