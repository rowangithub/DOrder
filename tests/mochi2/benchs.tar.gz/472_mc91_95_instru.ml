open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec m x =
  let r = if x > 100
          then let __atmp6 = 10 in x - __atmp6
          else
            (let __atmp4 = x + 11 in
             let __atmp3 = 
               let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_9_21" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in m __atmp4 in
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_7_21" in 
               let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
               let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
               let _ = if (!callflag) then fprintf outch ("\n") in m __atmp3)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "m" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = if n <= 95
          then
            let __atmp10 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "8_15_18" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in m n in
            assert (__atmp10 = 91)
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 