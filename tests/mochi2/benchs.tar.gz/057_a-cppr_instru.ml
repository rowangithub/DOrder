open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let make_array n i =
  let r = (let __atmp2 = 0 <= i in
           let __atmp4 = i < n in assert (__atmp2 && __atmp4));
          5
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "make_array" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let update (i : int) (n : int) des (x : int) =
  let r = let __atmp6 (j : int) =
            let r = if i = j
                    then x
                    else 
                      let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_37_42" in 
                      let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                      let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                      let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
                      let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
                      let _ = if (!callflag) then fprintf outch ("\n") in 
                      des j
               in let _ = if (!callflag) then fprintf outch ("name:%s\t") "__atmp6" 
            in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
            in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
            in let _ = if (!callflag) then fprintf outch ("\n") in r in
          let a = __atmp6 in a
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "update" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = for v0 = min([i-1;  n-1]) to max([i+1;  n+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("des:"); 
     fprintf outch ("des_0#%d,") ((v0));  
     (try fprintf outch ("des_r#%d\t") ((des v0)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let print_int (n : int) = let r = () 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "print_int" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let f (m : int) src des =
  let r = let rec bcopy (m : int) i (src : int -> int) (des : int -> int) =
            let r = if i >= m
                    then des
                    else
                      (let __atmp9 = 
                         let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_31_38" in 
                         let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                         let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                         let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                         let _ = if (!callflag) then fprintf outch ("\n") in 
                         src i in
                       let __atmp8 = 
                         let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_16_38" in 
                         let _ = if (!callflag) then fprintf outch ("\n") in 
                         update i m des __atmp9 in
                       let des = __atmp8 in
                       let __atmp10 = i + 1 in 
                         let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_6_27" in 
                         let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                         let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                         let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                         let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
                         let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
                         let _ = if (!callflag) then fprintf outch ("\n") in 
                         bcopy m __atmp10 src des)
               in let _ = if (!callflag) then fprintf outch ("name:%s\t") "bcopy" 
            in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
            in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
            in let _ = for v0 = min([m-1;  i-1;  m-1]) to max([m+1;  i+1; 
                         m+1]) do  
            if (!callflag) then ( (callflag := false); 
               fprintf outch ("src:");  fprintf outch ("src_0#%d,") ((v0));  
               (try fprintf outch ("src_r#%d\t") ((src v0)) with _->(fprintf outch ("	"))); 
               (callflag := true);) done 
            in let _ = for v0 = min([m-1;  i-1;  m-1]) to max([m+1;  i+1; 
                         m+1]) do  
            if (!callflag) then ( (callflag := false); 
               fprintf outch ("des:");  fprintf outch ("des_0#%d,") ((v0));  
               (try fprintf outch ("des_r#%d\t") ((des v0)) with _->(fprintf outch ("	"))); 
               (callflag := true);) done 
            in let _ = for v0 = min([m-1;  i-1;  m-1]) to max([m+1;  i+1; 
                         m+1]) do  
            if (!callflag) then ( (callflag := false); 
               fprintf outch ("r:");  fprintf outch ("r_0#%d,") ((v0));  
               (try fprintf outch ("r_r#%d\t") ((r v0)) with _->(fprintf outch ("	"))); 
               (callflag := true);) done 
            in let _ = if (!callflag) then fprintf outch ("\n") in r in
          let rec print_array m i (array : int -> int) =
            let r = if i >= m
                    then ()
                    else
                      ((let __atmp15 = 
                          let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_17_26" in 
                          let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                          let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                          let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                          let _ = if (!callflag) then fprintf outch ("\n") in 
                          array i in
                         let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_7_26" in 
                          let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                          let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                          let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                          let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
                          let _ = if (!callflag) then fprintf outch ("\n") in 
                          print_int __atmp15);
                       (let __atmp13 = i + 1 in 
                          let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_7_34" in 
                          let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                          let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                          let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                          let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
                          let _ = if (!callflag) then fprintf outch ("\n") in 
                          print_array m __atmp13 array))
               in let _ = if (!callflag) then fprintf outch ("name:%s\t") "print_array" 
            in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
            in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
            in let _ = for v0 = min([m-1;  i-1;  m-1]) to max([m+1;  i+1; 
                         m+1]) do  
            if (!callflag) then ( (callflag := false); 
               fprintf outch ("array:"); 
               fprintf outch ("array_0#%d,") ((v0));  
               (try fprintf outch ("array_r#%d\t") ((array v0)) with _->(fprintf outch ("	"))); 
               (callflag := true);) done 
            in let _ = if (!callflag) then fprintf outch ("\n") in r in
          let __atmp16: int -> int = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "23_27_44" in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in bcopy m 0 src
                                                                  des in
          let array = __atmp16 in
          let __atmp17 = 0 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "24_4_25" in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in print_array m
                                                                  __atmp17
                                                                  array
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = for v0 = min([m-1]) to max([m+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("src:"); 
     fprintf outch ("src_0#%d,") ((v0));  
     (try fprintf outch ("src_r#%d\t") ((src v0)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = for v0 = min([m-1]) to max([m+1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("des:"); 
     fprintf outch ("des_0#%d,") ((v0));  
     (try fprintf outch ("des_r#%d\t") ((des v0)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp18 = make_array n in
          let array1 = __atmp18 in
          let __atmp19 = make_array n in
          let array2 = __atmp19 in
          if n > 0
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "30_3_20" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f n array1
                                                                  array2
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp22 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "34_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp22
let _ = close_out outch 