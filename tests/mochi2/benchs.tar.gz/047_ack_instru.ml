open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec ackermann m n =
  let r = if m = 0
          then let __atmp13 = 1 in n + __atmp13
          else
            if n = 0
            then
              (let __atmp10 = m - 1 in
               let __atmp12 = 1 in 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "5_4_21" in 
                 let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                 let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 ackermann __atmp10 __atmp12)
            else
              (let __atmp5 = m - 1 in
               let __atmp8 = n - 1 in
               let __atmp7 = 
                 let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_20_39" in 
                 let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                 let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 ackermann m __atmp8 in
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_4_39" in 
                 let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                 let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
                 let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                 let _ = if (!callflag) then fprintf outch ("\n") in 
                 ackermann __atmp5 __atmp7)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "ackermann" 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main m n =
  let r = let __atmp15 = m >= 0 in
          let __atmp17 = n >= 0 in
          if __atmp15 && __atmp17
          then
            let __atmp20 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_46_59" in 
              let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") (if (__atmp15) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") (if (__atmp17) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("\n") in ackermann m
                                                                    n in
            assert (__atmp20 >= n)
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp21 = 2 in
  let __atmp22 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "11_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp21
                                                          __atmp22
let _ =
  let __atmp23 = 0 in
  let __atmp24 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") ((__atmp24)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp23
                                                          __atmp24
let _ =
  let __atmp25 = (-1) in
  let __atmp26 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp25
                                                          __atmp26
let _ = close_out outch 