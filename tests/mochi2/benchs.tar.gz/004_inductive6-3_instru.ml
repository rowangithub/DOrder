open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let f g x =
  let r = if x > 0
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_4_7" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in g x
          else 1
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = for x = min([0]) to max([x]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("g:"); 
     fprintf outch ("g_0#%d,") ((x));  
     (try fprintf outch ("g_r#%d\t") ((g x)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let decr x = let r = let __atmp3 = 1 in x - __atmp3 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "decr" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp5 = n >= 3 in
          let __atmp7 = n <= 0 in
          if __atmp5 || __atmp7
          then
            let __atmp10 = 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_45_53" in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") (if (__atmp5) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") (if (__atmp7) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("\n") in f decr n in
            assert (__atmp10 > 0)
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp12 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp12
let _ =
  let __atmp13 = 0 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp13
let _ = close_out outch 