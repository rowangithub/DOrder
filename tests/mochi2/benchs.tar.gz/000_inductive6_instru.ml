open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let f g x =
  let r = if x > 0
          then 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "3_4_7" in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in g x
          else 1
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "f" 
  in let _ = for x = min([0]) to max([x]) do 
  if (!callflag) then ( (callflag := false);  fprintf outch ("g:"); 
     fprintf outch ("g_0#%d,") ((x));  
     (try fprintf outch ("g_r#%d\t") ((g x)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let decr x = let r = let __atmp3 = 1 in x - __atmp3 
  in let _ = if (!callflag) then fprintf outch ("name:%s\t") "decr" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n =
  let r = let __atmp5 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_20_28" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in f decr 3 in
          assert (__atmp5 > 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp8 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "9_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp8
let _ = close_out outch 