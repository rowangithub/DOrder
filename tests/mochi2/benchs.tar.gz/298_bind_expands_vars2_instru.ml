open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop mc_i (n1 : int) n2 cp1_off maxdata =
  let r = if mc_i < n2
          then
            ((let __atmp5 = cp1_off + mc_i in
              let __atmp6 = maxdata * 2 in assert (__atmp5 < __atmp6));
             (let __atmp2 = mc_i + 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "4_2_37" in 
                let _ = if (!callflag) then fprintf outch ("mc_i:%d\t") ((mc_i)) in 
                let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
                let _ = if (!callflag) then fprintf outch ("n2:%d\t") ((n2)) in 
                let _ = if (!callflag) then fprintf outch ("cp1_off:%d\t") ((cp1_off)) in 
                let _ = if (!callflag) then fprintf outch ("maxdata:%d\t") ((maxdata)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp2
                                                                    n1 n2
                                                                    cp1_off
                                                                    maxdata))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("mc_i:%d\t") ((mc_i)) 
  in let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) 
  in let _ = if (!callflag) then fprintf outch ("n2:%d\t") ((n2)) 
  in let _ = if (!callflag) then fprintf outch ("cp1_off:%d\t") ((cp1_off)) 
  in let _ = if (!callflag) then fprintf outch ("maxdata:%d\t") ((maxdata)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n1 n2 cp1_off maxdata =
  let r = let __atmp9 = maxdata > 0 in
          let __atmp13 = maxdata * 2 in
          let __atmp12 = n1 <= __atmp13 in
          let __atmp16 = cp1_off <= n1 in
          let __atmp19 = maxdata * 2 in
          let __atmp18 = __atmp19 - n1 in
          let __atmp17 = n2 <= __atmp18 in
          let __atmp15 = __atmp16 && __atmp17 in
          let __atmp11 = __atmp12 && __atmp15 in
          if __atmp9 && __atmp11
          then
            let __atmp21 = 0 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "12_2_30" in 
              let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) in 
              let _ = if (!callflag) then fprintf outch ("n2:%d\t") ((n2)) in 
              let _ = if (!callflag) then fprintf outch ("cp1_off:%d\t") ((cp1_off)) in 
              let _ = if (!callflag) then fprintf outch ("maxdata:%d\t") ((maxdata)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") (if (__atmp9) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") (if (__atmp12) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") (if (__atmp16) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") (if (__atmp17) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") (if (__atmp15) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") (if (__atmp11) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp21
                                                                    n1 n2
                                                                    cp1_off
                                                                    maxdata
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n1:%d\t") ((n1)) 
  in let _ = if (!callflag) then fprintf outch ("n2:%d\t") ((n2)) 
  in let _ = if (!callflag) then fprintf outch ("cp1_off:%d\t") ((cp1_off)) 
  in let _ = if (!callflag) then fprintf outch ("maxdata:%d\t") ((maxdata)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp22 = 1 in
  let __atmp23 = 2 in
  let __atmp24 = 3 in
  let __atmp25 = 4 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_8_20" in 
    let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") ((__atmp24)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp22
                                                          __atmp23 __atmp24
                                                          __atmp25
let _ =
  let __atmp26 = (-1) in
  let __atmp27 = (-3) in
  let __atmp28 = (-5) in
  let __atmp29 = (-7) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_8_32" in 
    let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp28:%d\t") ((__atmp28)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp29:%d\t") ((__atmp29)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp26
                                                          __atmp27 __atmp28
                                                          __atmp29
let _ = close_out outch 