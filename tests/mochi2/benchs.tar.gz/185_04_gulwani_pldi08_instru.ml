open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop x y =
  let r = if x < 0
          then
            let __atmp5 = x + y in
            let x = __atmp5 in
            let __atmp6 = y + 1 in
            let y = __atmp6 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_2_10" in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
              let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
              let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop x y
          else assert (y > 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main y =
  let r = let __atmp8 = (-50) in
          let x = __atmp8 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_1_9" in 
            let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loop x y
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("y:%d\t") ((y)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp9 = 5 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_8_14" in 
    let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") ((__atmp9)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp9
let _ =
  let __atmp10 = (-5) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_8_17" in 
    let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp10
let _ = close_out outch 