open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let update a i x j =
  let r = if j = i
          then x
          else 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_40_43" in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) in 
            let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in a j
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "update" 
  in let _ = for v0 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("a:"); 
     fprintf outch ("a_0#%d,") ((v0));  
     (try fprintf outch ("a_r#%d\t") ((a v0); 0) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("x:%d\t") ((x)) 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec dotprod v1 v2 n i sum =
  let r = if i > n
          then sum
          else
            ((let __atmp10 = 0 <= i in
              let __atmp12 = i <= n in assert (__atmp10 && __atmp12));
             (let __atmp3 = i + 1 in
              let __atmp7 = 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_35_39" in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in v1 i in
              let __atmp8 = 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_42_46" in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in v2 i in
              let __atmp6 = __atmp7 * __atmp8 in
              let __atmp5 = sum + __atmp6 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "10_6_47" in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp3:%d\t") ((__atmp3)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp5:%d\t") ((__atmp5)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in dotprod
                                                                    v1 v2 n
                                                                    __atmp3
                                                                    __atmp5))
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "dotprod" 
  in let _ = for v0 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("v1:"); 
     fprintf outch ("v1_0#%d,") ((v0));  
     (try fprintf outch ("v1_r#%d\t") ((v1 v0)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = for v0 = min([-1]) to max([1]) do  
  if (!callflag) then ( (callflag := false);  fprintf outch ("v2:"); 
     fprintf outch ("v2_0#%d,") ((v0));  
     (try fprintf outch ("v2_r#%d\t") ((v2 v0)) with _->(fprintf outch ("	"))); 
     (callflag := true);) done 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("sum:%d\t") ((sum)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main i n =
  let r = let __atmp13 i = let r = 0 
            in let _ = if (!callflag) then fprintf outch ("name:%s\t") "__atmp13" 
            in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
            in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
            in let _ = if (!callflag) then fprintf outch ("\n") in r in
          let v1 = __atmp13 in
          let __atmp14 i = let r = 0 
            in let _ = if (!callflag) then fprintf outch ("name:%s\t") "__atmp14" 
            in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
            in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
            in let _ = if (!callflag) then fprintf outch ("\n") in r in
          let v2 = __atmp14 in
          (let __atmp15 = 0 in
           let __atmp16 = 0 in 
             let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_2_21" in 
             let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
             let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
             let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
             let _ = if (!callflag) then fprintf outch ("\n") in dotprod v1
                                                                   v2 n
                                                                   __atmp15
                                                                   __atmp16);
          ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ = close_out outch 