open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loopa i k n =
  let r = if i < n
          then
            let __atmp2 = i + 1 in
            let __atmp4 = k + 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "2_15_34" in 
              let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp2:%d\t") ((__atmp2)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loopa
                                                                    __atmp2
                                                                    __atmp4 n
          else k
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopa" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("r:%d\t") ((r)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let rec loopc i k m n =
  let r = let __atmp7 = m + n in
          if i < __atmp7
          then
            (assert (k > 0);
             (let __atmp8 = i + 1 in
              let __atmp10 = k - 1 in 
                let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_36_57" in 
                let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
                let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
                let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
                let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp7:%d\t") ((__atmp7)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp8:%d\t") ((__atmp8)) in 
                let _ = if (!callflag) then fprintf outch ("__atmp10:%d\t") ((__atmp10)) in 
                let _ = if (!callflag) then fprintf outch ("\n") in loopc
                                                                    __atmp8
                                                                    __atmp10
                                                                    m n))
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loopc" 
  in let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main n m =
  let r = let __atmp14 = 0 in
          let i = __atmp14 in
          let __atmp15 = 0 in
          let k = __atmp15 in
          let __atmp16 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "14_9_20" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopa i k n in
          let k = __atmp16 in
          let __atmp17 = 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "15_9_20" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopa i k m in
          let k = __atmp17 in 
            let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_1_14" in 
            let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
            let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
            let _ = if (!callflag) then fprintf outch ("i:%d\t") ((i)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
            let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
            let _ = if (!callflag) then fprintf outch ("\n") in loopc i k m n
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("m:%d\t") ((m)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp18 = 2 in
  let __atmp19 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp18
                                                          __atmp19
let _ =
  let __atmp20 = 3 in
  let __atmp21 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp21:%d\t") ((__atmp21)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp20
                                                          __atmp21
let _ =
  let __atmp22 = (-1) in
  let __atmp23 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "20_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp22:%d\t") ((__atmp22)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp23:%d\t") ((__atmp23)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp22
                                                          __atmp23
let _ =
  let __atmp24 = (-2) in
  let __atmp25 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "21_8_19" in 
    let _ = if (!callflag) then fprintf outch ("__atmp24:%d\t") ((__atmp24)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp25:%d\t") ((__atmp25)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp24
                                                          __atmp25
let _ =
  let __atmp26 = 2 in
  let __atmp27 = (-2) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "22_8_19" in 
    let _ = if (!callflag) then fprintf outch ("__atmp26:%d\t") ((__atmp26)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp27:%d\t") ((__atmp27)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp26
                                                          __atmp27
let _ = close_out outch 