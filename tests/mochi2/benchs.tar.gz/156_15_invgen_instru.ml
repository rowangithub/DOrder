open Printf
let xxxcounter = ref 1000 

let callflag = ref true 

let outch = open_out "mllog" 

let min l = List.fold_left (fun res li -> min res li) (-1) l 

let max l = List.fold_left (fun res li -> max res li) 0 l 
let rec loop j k n =
  let r = if j < n
          then
            let __atmp4 = j + 1 in
            let __atmp6 = k - 1 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "7_2_20" in 
              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp4:%d\t") ((__atmp4)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp6:%d\t") ((__atmp6)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop
                                                                    __atmp4
                                                                    __atmp6 n
          else assert (k >= 0)
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "loop" 
  in let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let main k n =
  let r = let __atmp9 = n > 0 in
          let __atmp11 = k > n in
          if __atmp9 && __atmp11
          then
            let __atmp12 = 0 in
            let j = __atmp12 in 
              let _ = if (!callflag) then fprintf outch ("env:%s\t") "13_2_12" in 
              let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) in 
              let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) in 
              let _ = if (!callflag) then fprintf outch ("__atmp9:%d\t") (if (__atmp9) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp11:%d\t") (if (__atmp11) then 1 else 0) in 
              let _ = if (!callflag) then fprintf outch ("__atmp12:%d\t") ((__atmp12)) in 
              let _ = if (!callflag) then fprintf outch ("j:%d\t") ((j)) in 
              let _ = if (!callflag) then fprintf outch ("\n") in loop j k n
          else ()
     in let _ = if (!callflag) then fprintf outch ("name:%s\t") "main" 
  in let _ = if (!callflag) then fprintf outch ("k:%d\t") ((k)) 
  in let _ = if (!callflag) then fprintf outch ("n:%d\t") ((n)) 
  in let _ = if (!callflag) then fprintf outch ("\n") in r
let _ =
  let __atmp13 = 4 in
  let __atmp14 = 2 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "16_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp13:%d\t") ((__atmp13)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp14:%d\t") ((__atmp14)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp13
                                                          __atmp14
let _ =
  let __atmp15 = 4 in
  let __atmp16 = 3 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "17_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp15:%d\t") ((__atmp15)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp16:%d\t") ((__atmp16)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp15
                                                          __atmp16
let _ =
  let __atmp17 = 2 in
  let __atmp18 = 1 in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "18_8_16" in 
    let _ = if (!callflag) then fprintf outch ("__atmp17:%d\t") ((__atmp17)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp18:%d\t") ((__atmp18)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp17
                                                          __atmp18
let _ =
  let __atmp19 = (-2) in
  let __atmp20 = (-1) in 
    let _ = if (!callflag) then fprintf outch ("env:%s\t") "19_8_22" in 
    let _ = if (!callflag) then fprintf outch ("__atmp19:%d\t") ((__atmp19)) in 
    let _ = if (!callflag) then fprintf outch ("__atmp20:%d\t") ((__atmp20)) in 
    let _ = if (!callflag) then fprintf outch ("\n") in main __atmp19
                                                          __atmp20
let _ = close_out outch 